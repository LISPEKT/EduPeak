// lib/data/[предмет]/[предмет]_data_ru.dart
import '../../../models/topic.dart';
import '../../../models/question.dart';
import '../../../models/subject.dart';

// === КЛАСС 1 ===
final List<Subject> [предмет]Subjects1 = [
Subject(
name: '[Название предмета]', // Например: 'Математика'
topicsByGrade: {
1: [
Topic(
id: "[предмет]_class1_topic1", // Например: "math_class1_numbers"
name: '[Тема для 1 класса]', // Например: 'Числа от 1 до 10'
paragraph: '[Название параграфа]', // Например: 'Числа и счёт'
imageAsset: '🔢', // Emoji остаются для тем
description: '[Описание для 1 класса]',
explanation: '[Объяснение для 1 класса]',
questions: [
Question(
text: '[Вопрос для 1 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
// Добавьте еще 9 вопросов...
],
),
Topic(
id: "[предмет]_class1_topic2",
name: '[Другая тема для 1 класса]',
paragraph: '[Название параграфа]', // Тот же параграф для группировки
imageAsset: '➕', // Emoji остаются
description: '[Описание]',
explanation: '[Объяснение]',
questions: [
Question(
text: '[Вопрос]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
// Добавьте другие темы для 1 класса...
],
},
),
];

// === КЛАСС 2 ===
final List<Subject> [предмет]Subjects2 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
2: [
Topic(
id: "[предмет]_class2_topic1",
name: '[Тема для 2 класса]',
paragraph: '[Название параграфа]',
imageAsset: '➖', // Emoji остаются
description: '[Описание для 2 класса]',
explanation: '[Объяснение для 2 класса]',
questions: [
Question(
text: '[Вопрос для 2 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
// Добавьте еще 9 вопросов...
],
),
],
},
),
];

// === КЛАСС 3 ===
final List<Subject> [предмет]Subjects3 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
3: [
Topic(
id: "[предмет]_class3_topic1",
name: '[Тема для 3 класса]',
paragraph: '[Название параграфа]',
imageAsset: '✖️', // Emoji остаются
description: '[Описание для 3 класса]',
explanation: '[Объяснение для 3 класса]',
questions: [
Question(
text: '[Вопрос для 3 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 4 ===
final List<Subject> [предмет]Subjects4 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
4: [
Topic(
id: "[предмет]_class4_topic1",
name: '[Тема для 4 класса]',
paragraph: '[Название параграфа]',
imageAsset: '➗', // Emoji остаются
description: '[Описание для 4 класса]',
explanation: '[Объяснение для 4 класса]',
questions: [
Question(
text: '[Вопрос для 4 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 5 ===
final List<Subject> [предмет]Subjects5 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
5: [
Topic(
id: "[предмет]_class5_topic1",
name: '[Тема для 5 класса]',
paragraph: '[Название параграфа]',
imageAsset: '📐', // Emoji остаются
description: '[Описание для 5 класса]',
explanation: '[Объяснение для 5 класса]',
questions: [
// Можно добавлять разные типы вопросов
Question(
text: '[Вопрос с одним вариантом]',
options: ['[Правильный]', '[Неправильный]', '[Неправильный]', '[Неправильный]', '[Неправильный]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
Question(
text: '[Вопрос с несколькими вариантами]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: [0, 2], // Несколько правильных ответов
explanation: '[Объяснение]',
answerType: 'multiple_choice',
),
Question(
text: '[Вопрос с текстовым ответом]',
options: ['[Правильный ответ]', '', '', '', ''],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'text',
),
],
),
],
},
),
];

// === КЛАСС 6 ===
final List<Subject> [предмет]Subjects6 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
6: [
Topic(
id: "[предмет]_class6_topic1",
name: '[Тема для 6 класса]',
paragraph: '[Название параграфа]',
imageAsset: '📊', // Emoji остаются
description: '[Описание для 6 класса]',
explanation: '[Объяснение для 6 класса]',
questions: [
Question(
text: '[Вопрос для 6 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 7 ===
final List<Subject> [предмет]Subjects7 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
7: [
Topic(
id: "[предмет]_class7_topic1",
name: '[Тема для 7 класса]',
paragraph: '[Название параграфа]',
imageAsset: '📈', // Emoji остаются
description: '[Описание для 7 класса]',
explanation: '[Объяснение для 7 класса]',
questions: [
Question(
text: '[Вопрос для 7 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 8 ===
final List<Subject> [предмет]Subjects8 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
8: [
Topic(
id: "[предмет]_class8_topic1",
name: '[Тема для 8 класса]',
paragraph: '[Название параграфа]',
imageAsset: '📉', // Emoji остаются
description: '[Описание для 8 класса]',
explanation: '[Объяснение для 8 класса]',
questions: [
Question(
text: '[Вопрос для 8 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 9 ===
final List<Subject> [предмет]Subjects9 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
9: [
Topic(
id: "[предмет]_class9_topic1",
name: '[Тема для 9 класса]',
paragraph: '[Название параграфа]',
imageAsset: '📚', // Emoji остаются
description: '[Описание для 9 класса]',
explanation: '[Объяснение для 9 класса]',
questions: [
Question(
text: '[Вопрос для 9 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 10 ===
final List<Subject> [предмет]Subjects10 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
10: [
Topic(
id: "[предмет]_class10_topic1",
name: '[Тема для 10 класса]',
paragraph: '[Название параграфа]',
imageAsset: '🎯', // Emoji остаются
description: '[Описание для 10 класса]',
explanation: '[Объяснение для 10 класса]',
questions: [
Question(
text: '[Вопрос для 10 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];

// === КЛАСС 11 ===
final List<Subject> [предмет]Subjects11 = [
Subject(
name: '[Название предмета]',
topicsByGrade: {
11: [
Topic(
id: "[предмет]_class11_topic1",
name: '[Тема для 11 класса]',
paragraph: '[Название параграфа]',
imageAsset: '🏆', // Emoji остаются
description: '[Описание для 11 класса]',
explanation: '[Объяснение для 11 класса]',
questions: [
Question(
text: '[Вопрос для 11 класса]',
options: ['[Вариант 1]', '[Вариант 2]', '[Вариант 3]', '[Вариант 4]', '[Вариант 5]'],
correctIndex: 0,
explanation: '[Объяснение]',
answerType: 'single_choice',
),
],
),
],
},
),
];