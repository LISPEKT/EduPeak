import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../localization.dart';
import '../data/user_data_storage.dart';

enum TimePeriod {
  week,
  month,
  year,
}

class XPScreen extends StatefulWidget {
  final Map<DateTime, int>? dailyXP;

  const XPScreen({
    Key? key,
    this.dailyXP,
  }) : super(key: key);

  @override
  State<XPScreen> createState() => _XPScreenState();
}

class _XPScreenState extends State<XPScreen> {
  TimePeriod _selectedPeriod = TimePeriod.week;
  Map<DateTime, int> _dailyXP = {};
  int _maxXP = 0;
  int _totalXP = 0;
  int _weeklyXP = 0;

  @override
  void initState() {
    super.initState();
    _loadXPData();
  }

  Future<void> _loadXPData() async {
    try {
      final stats = await UserDataStorage.getUserStats();
      final statsOverview = await UserDataStorage.getUserStatsOverview();

      final totalXP = statsOverview['totalXP'] as int? ?? 0;
      final weeklyXP = statsOverview['weeklyXP'] as int? ?? 0;

      // Загружаем историю XP (если есть)
      // Если передан dailyXP извне, используем его
      if (widget.dailyXP != null) {
        _dailyXP = widget.dailyXP!;
      } else {
        // Иначе генерируем тестовые данные или загружаем из хранилища
        _dailyXP = _generateXPHistory();
      }

      if (mounted) {
        setState(() {
          _totalXP = totalXP;
          _weeklyXP = weeklyXP;
          // Если у нас нет данных, добавляем текущий XP в историю
          if (_dailyXP.isEmpty && weeklyXP > 0) {
            _dailyXP[DateTime.now()] = weeklyXP;
          }
        });
      }
    } catch (e) {
      print('❌ Error loading XP data: $e');
    }
  }

  Map<DateTime, int> _generateXPHistory() {
    final today = DateTime.now();
    final history = <DateTime, int>{};

    // Генерируем тестовые данные для последних 30 дней
    final random = DateTime.now().millisecondsSinceEpoch;

    for (int i = 0; i < 30; i++) {
      final date = today.subtract(Duration(days: i));
      final dateKey = DateTime(date.year, date.month, date.day);

      // Случайное значение XP (0-200) с тенденцией к уменьшению с течением времени
      int xp = 0;
      if (i == 0) {
        // Сегодняшний день - текущий weeklyXP
        xp = _weeklyXP;
      } else {
        // Случайные данные для прошлых дней
        final chance = 70 - i * 2; // Вероятность активности уменьшается со временем
        if (chance > 0 && (random % 100) < chance) {
          xp = (random % 200).toInt() + 1;
        }
      }

      if (xp > 0) {
        history[dateKey] = xp;
      }
    }

    return history;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final localizations = AppLocalizations.of(context)!;

    // Подготавливаем данные в зависимости от выбранного периода
    final chartData = _prepareChartData();
    _maxXP = chartData.fold(0, (max, data) {
      final xp = data['xp'] as int;
      return xp > max ? xp : max;
    });

    // Вычисляем статистику
    final activeDays = chartData.where((data) => data['xp'] as int > 0).length;
    final totalXPSum = chartData.fold(0, (sum, data) => sum + (data['xp'] as int));
    final average = activeDays > 0 ? (totalXPSum / activeDays).round() : 0;
    final maxDailyXP = chartData.fold(0, (max, data) {
      final xp = data['xp'] as int;
      return xp > max ? xp : max;
    });

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      appBar: AppBar(
        title: Text(
          'График опыта',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: theme.colorScheme.surface,
        foregroundColor: theme.colorScheme.onSurface,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Информация о текущем XP
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Всего опыта',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                          Text(
                            '$_totalXP XP',
                            style: theme.textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.star_rounded,
                          color: Colors.blue,
                          size: 32,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  LinearProgressIndicator(
                    value: _totalXP > 10000 ? 1.0 : _totalXP / 10000,
                    backgroundColor: theme.colorScheme.surfaceVariant,
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(8),
                    minHeight: 8,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '0 XP',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      Text(
                        '10000 XP',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Переключатель периода
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildPeriodButton(
                    context,
                    '7 дней',
                    TimePeriod.week,
                    'Каждый день отдельно',
                  ),
                  _buildPeriodButton(
                    context,
                    'Месяц',
                    TimePeriod.month,
                    'Каждая неделя отдельно',
                  ),
                  _buildPeriodButton(
                    context,
                    'Год',
                    TimePeriod.year,
                    'Каждый месяц отдельно',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // График
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getTitleForPeriod(),
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _getSubtitleForPeriod(),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Сам график
                  SizedBox(
                    height: 220,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: chartData.map((data) {
                        final date = data['date'] as DateTime;
                        final xp = data['xp'] as int;
                        final label = data['label'] as String;
                        final subLabel = data['subLabel'] as String?;

                        // Вычисляем высоту столбца
                        final barHeight = _maxXP > 0
                            ? (xp / _maxXP) * 120
                            : 0;
                        final height = barHeight > 0 ? barHeight + 4 : 4;

                        return SizedBox(
                          width: 28,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              // Столбец
                              Container(
                                width: 20,
                                height: height.toDouble(),
                                decoration: BoxDecoration(
                                  color: xp > 0 ? Colors.blue : theme.colorScheme.surfaceVariant,
                                  borderRadius: BorderRadius.circular(6),
                                  gradient: xp > 0 ? LinearGradient(
                                    colors: [
                                      Colors.lightBlue.withOpacity(0.8),
                                      Colors.blue,
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ) : null,
                                ),
                              ),
                              const SizedBox(height: 6),

                              // Основная метка
                              Text(
                                label,
                                style: theme.textTheme.labelSmall?.copyWith(
                                  fontSize: 10,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),

                              // Дополнительная метка (если есть)
                              if (subLabel != null) ...[
                                const SizedBox(height: 2),
                                Text(
                                  subLabel,
                                  style: theme.textTheme.labelSmall?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant.withOpacity(0.7),
                                    fontSize: 8,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],

                              // Значение XP
                              const SizedBox(height: 2),
                              Text(
                                '$xp',
                                style: theme.textTheme.labelSmall?.copyWith(
                                  fontSize: 10,
                                  color: theme.colorScheme.onSurfaceVariant,
                                  fontWeight: FontWeight.w600,
                                ),
                                maxLines: 1,
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Легенда
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: theme.colorScheme.outline.withOpacity(0.1),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Получен опыт',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontSize: 13,
                      ),
                      maxLines: 2,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceVariant,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Опыт не получен',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontSize: 13,
                      ),
                      maxLines: 2,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Статистика
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Статистика опыта',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),

                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    childAspectRatio: 2.0,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    children: [
                      _buildStatItem(
                        context,
                        'Активных дней',
                        '$activeDays/${chartData.length}',
                        Icons.calendar_today_rounded,
                        Colors.green,
                      ),
                      _buildStatItem(
                        context,
                        'Всего XP',
                        '$totalXPSum',
                        Icons.star_rounded,
                        Colors.blue,
                      ),
                      _buildStatItem(
                        context,
                        'Максимум за день',
                        '$maxDailyXP',
                        Icons.arrow_upward_rounded,
                        Colors.orange,
                      ),
                      _buildStatItem(
                        context,
                        'Средний XP за день',
                        '$average',
                        Icons.timeline_rounded,
                        Colors.purple,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodButton(
      BuildContext context,
      String title,
      TimePeriod period,
      String subtitle,
      ) {
    final isSelected = _selectedPeriod == period;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedPeriod = period;
          });
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surfaceVariant,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected
                  ? Theme.of(context).colorScheme.primary
                  : Colors.transparent,
            ),
          ),
          child: Column(
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: isSelected
                      ? Theme.of(context).colorScheme.onPrimaryContainer
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                  color: isSelected
                      ? Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.8)
                      : Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.6),
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _prepareChartData() {
    final now = DateTime.now();
    final List<Map<String, dynamic>> data = [];

    switch (_selectedPeriod) {
      case TimePeriod.week:
      // 7 дней: каждый день отдельно
        for (int i = 6; i >= 0; i--) {
          final date = now.subtract(Duration(days: i));
          final dayKey = DateTime(date.year, date.month, date.day);
          final xp = _dailyXP[dayKey] ?? 0;

          data.add({
            'date': date,
            'xp': xp,
            'label': DateFormat('E').format(date)[0], // Пн, Вт и т.д.
            'subLabel': '${date.day}',
          });
        }
        break;

      case TimePeriod.month:
      // Месяц: каждая неделя отдельно (последние 4 недели)
        for (int i = 3; i >= 0; i--) {
          final startDate = now.subtract(Duration(days: i * 7 + 6));
          final endDate = now.subtract(Duration(days: i * 7));

          // Суммируем XP за неделю
          int weeklyXP = 0;
          for (int day = 0; day < 7; day++) {
            final date = startDate.add(Duration(days: day));
            final dayKey = DateTime(date.year, date.month, date.day);
            weeklyXP += _dailyXP[dayKey] ?? 0;
          }

          data.add({
            'date': endDate,
            'xp': weeklyXP,
            'label': 'Н${i + 1}',
            'subLabel': '${startDate.day}.${startDate.month}',
          });
        }
        break;

      case TimePeriod.year:
      // Год: каждый месяц отдельно (последние 12 месяцев)
        for (int i = 11; i >= 0; i--) {
          final monthDate = DateTime(now.year, now.month - i, 1);

          // Суммируем XP за месяц
          int monthlyXP = 0;
          final daysInMonth = DateTime(monthDate.year, monthDate.month + 1, 0).day;

          for (int day = 1; day <= daysInMonth; day++) {
            final date = DateTime(monthDate.year, monthDate.month, day);
            final dayKey = DateTime(date.year, date.month, date.day);
            monthlyXP += _dailyXP[dayKey] ?? 0;
          }

          data.add({
            'date': monthDate,
            'xp': monthlyXP,
            'label': DateFormat('MMM').format(monthDate),
            'subLabel': '${monthDate.year}',
          });
        }
        break;
    }

    return data;
  }

  String _getTitleForPeriod() {
    switch (_selectedPeriod) {
      case TimePeriod.week:
        return 'Опыт за 7 дней';
      case TimePeriod.month:
        return 'Опыт за месяц';
      case TimePeriod.year:
        return 'Опыт за год';
    }
  }

  String _getSubtitleForPeriod() {
    switch (_selectedPeriod) {
      case TimePeriod.week:
        return 'Каждый столбец показывает опыт за один день';
      case TimePeriod.month:
        return 'Каждый столбец показывает опыт за неделю';
      case TimePeriod.year:
        return 'Каждый столбец показывает опыт за месяц';
    }
  }

  Widget _buildStatItem(
      BuildContext context,
      String title,
      String value,
      IconData icon,
      Color color,
      ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 2,
                ),
                Text(
                  value,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}