import 'package:flutter/material.dart';
import '../data/user_data_storage.dart';
import '../data/subjects_data.dart';
import '../models/subject.dart';
import '../models/topic.dart';
import '../models/review_item.dart';
import '../localization.dart';
import 'topic_popup.dart';
import 'test_review_screen.dart';

class ReviewScreen extends StatefulWidget {
  final Function(int) onBottomNavTap;
  final int currentIndex;

  const ReviewScreen({
    Key? key,
    required this.onBottomNavTap,
    required this.currentIndex,
  }) : super(key: key);

  @override
  _ReviewScreenState createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  List<ReviewItem> _reviewItems = [];
  List<ReviewItem> _startedTopicsItems = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReviewData();
  }

  Future<void> _loadReviewData() async {
    try {
      final stats = await UserDataStorage.getUserStats();
      final subjectsData = getSubjectsByGrade(context);

      List<ReviewItem> startedTopicsItems = [];
      Set<String> usedQuestionIds = {};

      for (final grade in subjectsData.keys) {
        final subjects = subjectsData[grade] ?? [];
        for (final subject in subjects) {
          final topics = subject.topicsByGrade[grade] ?? [];
          for (final topic in topics) {
            final topicProgress = stats.topicProgress[subject.name]?[topic.id] ?? 0;

            // Только для тем, которые начаты (progress > 0)
            if (topicProgress > 0) {
              // Добавляем только те вопросы, которые ЕЩЕ НЕ были отвечены правильно
              // Если topicProgress = 3, значит первые 3 вопроса уже отвечены
              // Добавляем вопросы начиная с 4-го (индекс 3)
              for (int i = topicProgress; i < topic.questions.length; i++) {
                final questionId = '${subject.name}_${topic.id}_$i';

                if (!usedQuestionIds.contains(questionId) && i < topic.questions.length) {
                  startedTopicsItems.add(ReviewItem(
                    question: topic.questions[i],
                    topic: topic,
                    subject: subject.name,
                    grade: grade,
                    questionIndex: i,
                  ));
                  usedQuestionIds.add(questionId);

                  // Ограничиваем количество вопросов для каждой темы (макс 5)
                  final questionsInThisTopic = startedTopicsItems.where((item) =>
                  item.topic.id == topic.id && item.subject == subject.name).length;
                  if (questionsInThisTopic >= 5) {
                    break;
                  }
                }
              }
            }
          }
        }
      }

      setState(() {
        _reviewItems = startedTopicsItems;
        _startedTopicsItems = startedTopicsItems;
        _isLoading = false;
      });

    } catch (e) {
      print('❌ Error loading review data: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _startReviewTest() {
    if (_startedTopicsItems.isEmpty) return;

    // Создаем список уникальных тем для теста
    final List<ReviewItem> uniqueTopicItems = [];
    final Set<String> usedTopics = {};

    for (final item in _startedTopicsItems) {
      final topicKey = '${item.subject}_${item.topic.id}';
      if (!usedTopics.contains(topicKey)) {
        uniqueTopicItems.add(item);
        usedTopics.add(topicKey);
      }
    }

    final testQuestions = uniqueTopicItems.length > 10
        ? uniqueTopicItems.sublist(0, 10)
        : List<ReviewItem>.from(uniqueTopicItems);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TestReviewScreen(
          reviewItems: testQuestions,
          testTitle: 'Повторение тем',
        ),
      ),
    );
  }

  void _openTopic(ReviewItem item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => TopicPopup(
        topic: item.topic,
        currentGrade: item.grade,
        currentSubject: item.subject,
      ),
    );
  }

  String _getQuestionText(dynamic question) {
    try {
      if (question is Map<String, dynamic>) {
        return question['text'] ?? 'Вопрос';
      } else {
        return 'Вопрос из темы';
      }
    } catch (e) {
      return 'Вопрос';
    }
  }

  @override
  Widget build(BuildContext context) {
    final appLocalizations = AppLocalizations.of(context)!;

    if (_isLoading) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text(
                'Загружаем темы для повторения...',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Заголовок с отступом сверху
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text(
                  appLocalizations.review,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Карточка статистики
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _StatCard(
                      title: 'Всего вопросов',
                      value: _reviewItems.length,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    _StatCard(
                      title: 'Начатые темы',
                      value: _startedTopicsItems.length,
                      color: Theme.of(context).colorScheme.secondary,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Кнопка повторения
              if (_startedTopicsItems.isNotEmpty)
                Container(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _startReviewTest,
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      foregroundColor: Theme.of(context).colorScheme.onPrimary,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.refresh_rounded, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Повторить темы (${_startedTopicsItems.length > 10 ? 10 : _startedTopicsItems.length} вопросов)',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              else
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.school_rounded,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Начните изучать темы для повторения!',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onPrimaryContainer,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 32),

              // Список вопросов
              if (_startedTopicsItems.isNotEmpty) ...[
                Text(
                  'Начатые темы для повторения:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                ..._startedTopicsItems.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _QuestionCard(
                      item: item,
                      onTap: () => _openTopic(item),
                      questionText: _getQuestionText(item.question),
                    ),
                  );
                }).toList(),
              ] else
                _buildEmptyState(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.school_rounded,
              size: 80,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
            ),
            SizedBox(height: 24),
            Text(
              'Пока нет начатых тем',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 12),
            Text(
              'Начните изучать темы, и они появятся здесь для повторения',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            SizedBox(height: 32),
            FilledButton(
              onPressed: () {
                widget.onBottomNavTap(0);
              },
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Theme.of(context).colorScheme.onPrimary,
                padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text('Начать изучение'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final int value;
  final Color color;

  const _StatCard({
    required this.title,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: color.withOpacity(0.2), width: 2),
          ),
          child: Center(
            child: Text(
              value.toString(),
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        SizedBox(height: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

class _QuestionCard extends StatelessWidget {
  final ReviewItem item;
  final VoidCallback onTap;
  final String questionText;

  const _QuestionCard({
    required this.item,
    required this.onTap,
    required this.questionText,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      color: Theme.of(context).colorScheme.surface,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.school_rounded,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  size: 20,
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      questionText,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4),
                    Text(
                      '${item.subject} • ${item.topic.name}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 16,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
              ),
            ],
          ),
        ),
      ),
    );
  }
}