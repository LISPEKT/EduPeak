import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import '../data/subjects_data.dart';
import '../data/user_data_storage.dart';
import '../models/user_stats.dart';
import '../models/subject.dart';
import '../models/topic.dart';
import '../theme/app_theme.dart';
import 'topic_popup.dart';
import 'settings_screen.dart';
import 'auth_screen.dart';
import 'profile_screen.dart';
import 'profile_editor_screen.dart';
import 'statistics_screen.dart';
import 'subscription_screen.dart';
import '../services/api_service.dart';
import '../localization.dart';
import '../data/subjects_manager.dart';
import 'get_xp_screen.dart';
import 'friends_screen.dart';
import 'achievements_screen.dart';
import 'eduleague_screen.dart';
import 'review_screen.dart';
import 'dictionary_screen.dart';
import 'subject_screen.dart';

class MainScreen extends StatefulWidget {
  final VoidCallback onLogout;

  const MainScreen({Key? key, required this.onLogout}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with WidgetsBindingObserver {
  int _currentBottomNavIndex = 0;
  String _username = '';
  String _avatar = '👤';
  UserStats _userStats = UserStats(
    streakDays: 0,
    lastActivity: DateTime.now(),
    topicProgress: {},
    dailyCompletion: {},
    username: '',
    totalXP: 0,
    weeklyXP: 0,
    lastWeeklyReset: DateTime.now(),
  );

  Map<String, bool> _expandedSubjects = {};
  List<String> _selectedSubjects = [];
  List<String> _availableSubjects = [];
  bool _isEditingMode = false;
  DateTime? _lastDataUpdate;
  final ScrollController _scrollController = ScrollController();
  bool _showSearchBar = false;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkAuthStatus();
    _loadUserData();
    _loadSelectedSubjects();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _currentBottomNavIndex == 0) {
      _loadUserData();
    }
  }

  Future<void> _loadUserData() async {
    try {
      final stats = await UserDataStorage.getUserStats();
      final username = await UserDataStorage.getUsername();
      final avatar = await UserDataStorage.getAvatar();

      if (mounted) {
        setState(() {
          _userStats = stats;
          _username = username;
          _avatar = avatar;
          _lastDataUpdate = DateTime.now();
        });
      }
    } catch (e) {
      print('❌ Error loading user data: $e');
    }
  }

  Future<void> _loadSelectedSubjects() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedSubjects = prefs.getStringList('selectedSubjects');

      final allSubjects = _getAllSubjects();

      if (mounted) {
        setState(() {
          _availableSubjects = allSubjects;
          _selectedSubjects = savedSubjects ?? allSubjects;
        });
      }
    } catch (e) {
      print('❌ Error loading selected subjects: $e');
    }
  }

  Future<void> _saveSelectedSubjects() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('selectedSubjects', _selectedSubjects);
    } catch (e) {
      print('❌ Error saving selected subjects: $e');
    }
  }

  List<String> _getAllSubjects() {
    final allSubjects = <String>{};
    for (final grade in getSubjectsByGrade(context).keys) {
      final subjects = getSubjectsByGrade(context)[grade] ?? [];
      for (final subject in subjects) {
        allSubjects.add(subject.name);
      }
    }
    return allSubjects.toList();
  }

  List<String> get _subjectsToAdd {
    return _availableSubjects
        .where((subject) => !_selectedSubjects.contains(subject))
        .toList();
  }

  Future<void> _checkAuthStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

      if (!isLoggedIn && mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const AuthScreen()),
              (route) => false,
        );
      }
    } catch (e) {
      print('Error checking auth status: $e');
    }
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _currentBottomNavIndex = index;
    });

    if (index == 0 && mounted) {
      final now = DateTime.now();
      if (_lastDataUpdate == null ||
          now.difference(_lastDataUpdate!).inSeconds > 5) {
        _loadUserData();
      }
    }
  }

  List<int> _getGradesForSubject(String subjectName) {
    final grades = <int>{};
    for (final grade in getSubjectsByGrade(context).keys) {
      final subjects = getSubjectsByGrade(context)[grade] ?? [];
      for (final subject in subjects) {
        if (subject.name == subjectName) {
          grades.add(grade);
        }
      }
    }
    return grades.toList()..sort();
  }

  Widget _getCurrentScreen() {
    switch (_currentBottomNavIndex) {
      case 0:
        return _buildHomeScreenContent();
      case 1:
        return ReviewScreen(
          onBottomNavTap: _onBottomNavTap,
          currentIndex: _currentBottomNavIndex,
        );
      case 2:
        return DictionaryScreen(
          onBottomNavTap: _onBottomNavTap,
          currentIndex: _currentBottomNavIndex,
        );
      case 3:
        return const SubscriptionScreen();
      case 4:
        return ProfileScreen(
          onBottomNavTap: _onBottomNavTap,
          currentIndex: _currentBottomNavIndex,
          onLogout: widget.onLogout,
        );
      default:
        return _buildHomeScreenContent();
    }
  }

  void _addSubject(String subject) {
    if (!_selectedSubjects.contains(subject)) {
      setState(() {
        _selectedSubjects.add(subject);
        _isEditingMode = false;
      });
      _saveSelectedSubjects();
    }
  }

  void _removeSubject(String subject) {
    setState(() {
      _selectedSubjects.remove(subject);
    });
    _saveSelectedSubjects();
  }

  void _showAddSubjectsDialog() {
    final subjectsToAdd = _subjectsToAdd;

    if (subjectsToAdd.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _selectedSubjects.isEmpty
                ? 'Все предметы уже добавлены'
                : 'Нет предметов для добавления',
          ),
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(28),
              topRight: Radius.circular(28),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Добавить предмет',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => Navigator.pop(context),
                      visualDensity: VisualDensity.compact,
                    ),
                  ],
                ),
              ),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: const AlwaysScrollableScrollPhysics(),
                  itemCount: subjectsToAdd.length,
                  itemBuilder: (context, index) {
                    final subject = subjectsToAdd[index];
                    final color = _getSubjectColor(subject);

                    return ListTile(
                      leading: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          _getSubjectIcon(subject),
                          color: color,
                        ),
                      ),
                      title: Text(subject),
                      onTap: () {
                        _addSubject(subject);
                        Navigator.pop(context);
                      },
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
            ],
          ),
        );
      },
    );
  }

  Color _getSubjectColor(String subject) {
    final colors = {
      'Математика': const Color(0xFF6366F1),
      'Русский язык': const Color(0xFFEF4444),
      'Литература': const Color(0xFFF59E0B),
      'История': const Color(0xFF10B981),
      'Обществознание': const Color(0xFF8B5CF6),
      'География': const Color(0xFF06B6D4),
      'Биология': const Color(0xFF84CC16),
      'Физика': const Color(0xFF3B82F6),
      'Химия': const Color(0xFFF97316),
      'Английский язык': const Color(0xFFEC4899),
    };
    return colors[subject] ?? Colors.grey;
  }

  IconData _getSubjectIcon(String subject) {
    final icons = {
      'Математика': Icons.calculate_rounded,
      'Русский язык': Icons.menu_book_rounded,
      'Литература': Icons.book_rounded,
      'История': Icons.history_rounded,
      'Обществознание': Icons.people_rounded,
      'География': Icons.public_rounded,
      'Биология': Icons.eco_rounded,
      'Физика': Icons.science_rounded,
      'Химия': Icons.science_rounded,
      'Английский язык': Icons.language_rounded,
    };
    return icons[subject] ?? Icons.subject_rounded;
  }

  bool _isPhotoAvatar() {
    return _avatar.startsWith('/');
  }

  Widget _buildHomeScreenContent() {
    final appLocalizations = AppLocalizations.of(context);
    final filteredSubjects = _searchQuery.isEmpty
        ? _selectedSubjects
        : _selectedSubjects
        .where((subject) =>
        subject.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: SafeArea(
        child: Column(
          children: [
            // Верхний бар с аватаркой и поиском
            Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _username.isNotEmpty
                                  ? 'Привет, $_username!'
                                  : 'Привет!',
                              style:
                              Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w700,
                                color:
                                Theme.of(context).colorScheme.onSurface,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Что будем изучать сегодня?',
                              style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurface
                                    .withOpacity(0.6),
                              ),
                            ),
                          ],
                        ),
                        GestureDetector(
                          onTap: () => _onBottomNavTap(4),
                          child: Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Theme.of(context).colorScheme.primary,
                                  Theme.of(context).colorScheme.secondary,
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: _isPhotoAvatar()
                                ? ClipOval(
                              child: Image.file(
                                File(_avatar),
                                fit: BoxFit.cover,
                                width: 48,
                                height: 48,
                                errorBuilder: (context, error, stackTrace) {
                                  return Icon(
                                    Icons.person_rounded,
                                    color: Colors.white,
                                    size: 24,
                                  );
                                },
                              ),
                            )
                                : Center(
                              child: Text(
                                _avatar,
                                style: const TextStyle(fontSize: 24),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Строка поиска
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceVariant,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Row(
                        children: [
                          const SizedBox(width: 16),
                          Icon(
                            Icons.search_rounded,
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withOpacity(0.5),
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextField(
                              controller: TextEditingController(text: _searchQuery),
                              onChanged: (value) {
                                setState(() {
                                  _searchQuery = value;
                                });
                              },
                              decoration: InputDecoration(
                                hintText: 'Поиск предметов...',
                                hintStyle: TextStyle(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurface
                                      .withOpacity(0.5),
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.zero,
                              ),
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurface,
                              ),
                            ),
                          ),
                          if (_searchQuery.isNotEmpty)
                            IconButton(
                              icon: Icon(
                                Icons.close_rounded,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurface
                                    .withOpacity(0.5),
                                size: 20,
                              ),
                              onPressed: () {
                                setState(() {
                                  _searchQuery = '';
                                });
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Заголовок и кнопки управления
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Мои предметы',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${_selectedSubjects.length}/${_availableSubjects.length}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: Icon(Icons.add_rounded, size: 20),
                          color: Theme.of(context).colorScheme.primary,
                          onPressed: _showAddSubjectsDialog,
                          padding: EdgeInsets.zero,
                          tooltip: 'Добавить предмет',
                        ),
                      ),
                      const SizedBox(width: 8),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          gradient: _isEditingMode
                              ? LinearGradient(
                            colors: [
                              const Color(0xFF10B981),
                              const Color(0xFF34D399),
                            ],
                          )
                              : LinearGradient(
                            colors: [
                              Theme.of(context).colorScheme.primary,
                              Theme.of(context).colorScheme.secondary,
                            ],
                          ),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: (_isEditingMode
                                  ? const Color(0xFF10B981)
                                  : Theme.of(context).colorScheme.primary)
                                  .withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: IconButton(
                          icon: Icon(
                            _isEditingMode
                                ? Icons.check_rounded
                                : Icons.edit_rounded,
                            size: 20,
                          ),
                          color: Colors.white,
                          onPressed: () {
                            setState(() {
                              _isEditingMode = !_isEditingMode;
                            });
                            if (!_isEditingMode) {
                              _saveSelectedSubjects();
                            }
                          },
                          padding: EdgeInsets.zero,
                          tooltip: _isEditingMode ? 'Готово' : 'Редактировать',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Основной контент с предметами
            Expanded(
              child: filteredSubjects.isEmpty
                  ? _buildEmptyState()
                  : _isEditingMode
                  ? ReorderableListView.builder(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                itemCount: filteredSubjects.length,
                onReorder: (oldIndex, newIndex) {
                  setState(() {
                    if (oldIndex < newIndex) {
                      newIndex -= 1;
                    }
                    final item = filteredSubjects.removeAt(oldIndex);
                    filteredSubjects.insert(newIndex, item);
                    _selectedSubjects = filteredItems;
                  });
                  _saveSelectedSubjects();
                },
                itemBuilder: (context, index) {
                  final subject = filteredSubjects[index];
                  final grades = _getGradesForSubject(subject);

                  return Container(
                    key: ValueKey('$subject-$index'),
                    margin: const EdgeInsets.only(bottom: 12),
                    child: _ModernSubjectCard(
                      subject: subject,
                      isExpanded: false,
                      grades: grades,
                      subjectColor: _getSubjectColor(subject),
                      subjectIcon: _getSubjectIcon(subject),
                      isEditingMode: true,
                      onToggle: () {},
                      onGradeSelected: (grade) {},
                      onRemove: () {
                        _removeSubject(subject);
                      },
                      searchQuery: _searchQuery,
                    ),
                  );
                },
              )
                  : ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                itemCount: filteredSubjects.length,
                itemBuilder: (context, index) {
                  final subject = filteredSubjects[index];
                  final isExpanded = _expandedSubjects[subject] ?? false;
                  final grades = _getGradesForSubject(subject);

                  return _ModernSubjectCard(
                    subject: subject,
                    isExpanded: isExpanded,
                    grades: grades,
                    subjectColor: _getSubjectColor(subject),
                    subjectIcon: _getSubjectIcon(subject),
                    isEditingMode: false,
                    onToggle: () {
                      setState(() {
                        _expandedSubjects[subject] = !isExpanded;
                      });
                    },
                    onGradeSelected: (grade) {
                      _openSubjectScreen(subject, grade);
                    },
                    onRemove: () {
                      _removeSubject(subject);
                    },
                    searchQuery: _searchQuery,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<String> get filteredItems => _searchQuery.isEmpty
      ? _selectedSubjects
      : _selectedSubjects
      .where((subject) =>
      subject.toLowerCase().contains(_searchQuery.toLowerCase()))
      .toList();

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                Theme.of(context).colorScheme.primary.withOpacity(0.1),
            Theme.of(context).colorScheme.secondary.withOpacity(0.1),
          ),
          shape: BoxShape.circle,
        ),
        child: Icon(
          Icons.school_rounded,
          size: 60,
          color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
        ),
      ),
      const SizedBox(height: 24),
      Text(
        'Нет выбранных предметов',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 12),
      Text(
        'Добавьте предметы, чтобы начать обучение',
        style: TextStyle(
          color:
          Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.6),
        ),
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 32),
      ElevatedButton(
        onPressed: _showAddSubjectsDialog,
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).colorScheme.primary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.symmetric(
              horizontal: 32, vertical: 16),
          elevation: 0,
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.add_rounded, size: 20),
            SizedBox(width: 8),
            Text('Добавить предметы'),
          ],
        ),
      ),
      ],
    ),
    ),
    );
  }

  void _openSubjectScreen(String subject, int grade) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SubjectScreen(
          subjectName: subject,
          grade: grade,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness:
          Theme.of(context).brightness == Brightness.dark
              ? Brightness.light
              : Brightness.dark,
          statusBarBrightness: Theme.of(context).brightness == Brightness.dark
              ? Brightness.dark
              : Brightness.light,
        ),
        child: _getCurrentScreen(),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildBottomNavigationBar() {
    final appLocalizations = AppLocalizations.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      height: 70,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          _buildNavItem(
            index: 0,
            icon: Icons.home_outlined,
            selectedIcon: Icons.home_filled,
            label: appLocalizations?.home ?? 'Главная',
          ),
          _buildNavItem(
            index: 1,
            icon: Icons.refresh_outlined,
            selectedIcon: Icons.refresh,
            label: appLocalizations?.review ?? 'Повторение',
          ),
          _buildNavItem(
            index: 2,
            icon: Icons.book_outlined,
            selectedIcon: Icons.book,
            label: appLocalizations?.dictionary ?? 'Словарь',
          ),
          _buildNavItem(
            index: 3,
            icon: Icons.star_outlined,
            selectedIcon: Icons.star,
            label: 'Premium',
          ),
          _buildNavItem(
            index: 4,
            icon: Icons.person_outlined,
            selectedIcon: Icons.person,
            label: appLocalizations?.profile ?? 'Профиль',
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required IconData selectedIcon,
    required String label,
  }) {
    final isSelected = index == _currentBottomNavIndex;

    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _onBottomNavTap(index),
          borderRadius: BorderRadius.circular(20),
          child: Container(
            height: 70,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? LinearGradient(
                      colors: [
                        Theme.of(context).colorScheme.primary,
                        Theme.of(context).colorScheme.secondary,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                        : null,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isSelected ? selectedIcon : icon,
                    size: 20,
                    color: isSelected
                        ? Colors.white
                        : Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    color: isSelected
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModernSubjectCard extends StatelessWidget {
  final String subject;
  final bool isExpanded;
  final List<int> grades;
  final Color subjectColor;
  final IconData subjectIcon;
  final bool isEditingMode;
  final VoidCallback onToggle;
  final Function(int) onGradeSelected;
  final VoidCallback? onRemove;
  final String searchQuery;

  const _ModernSubjectCard({
    required this.subject,
    required this.isExpanded,
    required this.grades,
    required this.subjectColor,
    required this.subjectIcon,
    required this.isEditingMode,
    required this.onToggle,
    required this.onGradeSelected,
    this.onRemove,
    required this.searchQuery,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.2 : 0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: !isEditingMode ? onToggle : null,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              subjectColor.withOpacity(0.2),
                              subjectColor.withOpacity(0.1),
                            ],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            subjectIcon,
                            color: subjectColor,
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                subject,
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: textColor,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${grades.length} класс${grades.length % 10 == 1 ? '' : 'ов'}',
                                style: TextStyle(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurface
                                      .withOpacity(0.6),
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (!isEditingMode)
                    Icon(
                      isExpanded
                          ? Icons.expand_less_rounded
                          : Icons.expand_more_rounded,
                      color: Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withOpacity(0.5),
                    ),
                    if (isEditingMode && onRemove != null)
                      IconButton(
                        icon: Icon(
                          Icons.close_rounded,
                          color: Theme.of(context).colorScheme.error,
                          size: 20,
                        ),
                        onPressed: onRemove,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(
                          minWidth: 40,
                          minHeight: 40,
                        ),
                      ),
                  ],
                ),
                if (isExpanded && !isEditingMode)
                  Column(
                    children: [
                      const SizedBox(height: 16),
                      Divider(
                        height: 1,
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.1),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Выберите класс:',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                          color: textColor,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: grades.map((grade) {
                          return _ModernGradeChip(
                            grade: grade,
                            onTap: () => onGradeSelected(grade),
                            color: subjectColor,
                          );
                        }).toList(),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModernGradeChip extends StatelessWidget {
  final int grade;
  final VoidCallback onTap;
  final Color color;

  const _ModernGradeChip({
    required this.grade,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: color.withOpacity(0.3),
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    '$grade',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'класс',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}