import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import '../data/user_data_storage.dart';
import '../models/user_stats.dart';
import '../localization.dart';
import '../data/subjects_data.dart';
import 'profile_editor_screen.dart';
import 'statistics_screen.dart';
import 'achievements_screen.dart';
import 'eduleague_screen.dart';
import 'streak_screen.dart';
import 'xp_screen.dart';
import 'settings_screen.dart';
import 'friends_screen.dart';

class ProfileScreen extends StatefulWidget {
  final Function(int) onBottomNavTap;
  final int currentIndex;
  final VoidCallback onLogout;

  const ProfileScreen({
    Key? key,
    required this.onBottomNavTap,
    required this.currentIndex,
    required this.onLogout,
  }) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String _username = '';
  String _avatar = '👤';
  DateTime? _registrationDate;
  UserStats _userStats = UserStats(
    streakDays: 0,
    lastActivity: DateTime.now(),
    topicProgress: {},
    dailyCompletion: {},
    username: '',
    totalXP: 0,
    weeklyXP: 0,
    lastWeeklyReset: DateTime.now(),
  );
  List<String> _selectedSubjects = [];
  int _totalXP = 0;
  int _weeklyXP = 0;
  String _currentLeague = 'Новичок';
  String _mostPopularSubject = 'Математика';
  int _completedTopics = 0;
  int _correctAnswers = 0;
  int _achievementsCompleted = 0;
  int _totalAchievements = 0;
  int _friendsCount = 0;
  Map<DateTime, int> _dailyActivity = {};
  Map<DateTime, int> _dailyXP = {};
  Map<String, double> _subjectProgress = {};
  List<Map<String, dynamic>> _friendsList = [];
  List<Map<String, dynamic>> _achievementsList = [];

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadUserStats();
    _loadSelectedSubjects();
    _loadFriendsData();
    _loadAchievementsData();
    _calculateSubjectProgress();
  }

  Future<void> _loadUserData() async {
    try {
      final username = await UserDataStorage.getUsername();
      final avatar = await UserDataStorage.getAvatar();
      final prefs = await SharedPreferences.getInstance();
      final registrationTimestamp = prefs.getInt('registrationDate') ?? DateTime.now().millisecondsSinceEpoch;

      if (mounted) {
        setState(() {
          _username = username;
          _avatar = avatar;
          _registrationDate = DateTime.fromMillisecondsSinceEpoch(registrationTimestamp);
        });
      }
    } catch (e) {
      print('❌ Error loading user data: $e');
    }
  }

  Future<void> _loadUserStats() async {
    try {
      final stats = await UserDataStorage.getUserStats();
      final statsOverview = await UserDataStorage.getUserStatsOverview();

      // Используем данные из getStatsOverview для точных значений
      final totalXP = statsOverview['totalXP'] as int? ?? 0;
      final weeklyXP = statsOverview['weeklyXP'] as int? ?? 0;
      final completedTopics = statsOverview['completedTopics'] as int? ?? 0;
      final correctAnswers = statsOverview['totalCorrectAnswers'] as int? ?? 0;
      final currentLeague = statsOverview['currentLeague'] as String? ?? 'Бронза';
      final username = statsOverview['username'] as String? ?? '';

      // Находим самый популярный предмет
      String popularSubject = 'Нет данных';
      int maxTopics = 0;
      if (stats.topicProgress.isNotEmpty) {
        for (final subject in stats.topicProgress.keys) {
          final topicCount = stats.topicProgress[subject]?.length ?? 0;
          if (topicCount > maxTopics) {
            maxTopics = topicCount;
            popularSubject = subject;
          }
        }
      }

      if (mounted) {
        setState(() {
          _userStats = stats;
          _totalXP = totalXP;
          _weeklyXP = weeklyXP;
          _completedTopics = completedTopics;
          _correctAnswers = correctAnswers;
          _currentLeague = currentLeague;
          _mostPopularSubject = popularSubject;
          _username = username.isNotEmpty ? username : _username;
        });
      }

      // После загрузки статистики пересчитываем прогресс по предметам
      _calculateSubjectProgress();

    } catch (e) {
      print('❌ Error loading user stats: $e');
    }
  }

  // Новый метод: загрузка данных друзей как на FriendsScreen
  Future<void> _loadFriendsData() async {
    try {
      // Имитируем загрузку данных как в FriendsScreen
      // В реальном приложении здесь будет вызов API
      final friendsData = await _simulateFriendsApiCall();

      if (mounted) {
        setState(() {
          _friendsList = friendsData;
          _friendsCount = friendsData.length;
        });
      }

      print('✅ Loaded friends: $_friendsCount');

    } catch (e) {
      print('❌ Error loading friends data: $e');
      // Fallback: создаем тестовые данные
      _createMockFriendsData();
    }
  }

  // Метод-заглушка для имитации API вызова
  Future<List<Map<String, dynamic>>> _simulateFriendsApiCall() async {
    await Future.delayed(Duration(milliseconds: 100));

    // Возвращаем тестовые данные друзей
    return [
      {
        'id': '1',
        'name': 'Александр Иванов',
        'username': 'alex_ivanov',
        'streakDays': 7,
        'completedTopics': 15,
        'correctAnswers': 120,
        'avatar': '👨‍🎓',
        'currentLeague': 'Серебро',
        'weeklyXP': 450,
        'isOnline': true,
      },
      {
        'id': '2',
        'name': 'Мария Петрова',
        'username': 'maria_petrova',
        'streakDays': 14,
        'completedTopics': 22,
        'correctAnswers': 180,
        'avatar': '👩‍🎓',
        'currentLeague': 'Золото',
        'weeklyXP': 620,
        'isOnline': false,
      },
      {
        'id': '3',
        'name': 'Иван Сидоров',
        'username': 'ivan_sidorov',
        'streakDays': 3,
        'completedTopics': 8,
        'correctAnswers': 65,
        'avatar': '👨‍💼',
        'currentLeague': 'Бронза',
        'weeklyXP': 210,
        'isOnline': true,
      },
      {
        'id': '4',
        'name': 'Екатерина Козлова',
        'username': 'ekaterina_kozlova',
        'streakDays': 21,
        'completedTopics': 30,
        'correctAnswers': 240,
        'avatar': '👩‍🏫',
        'currentLeague': 'Платина',
        'weeklyXP': 780,
        'isOnline': false,
      },
    ];
  }

  void _createMockFriendsData() {
    setState(() {
      _friendsList = [
        {
          'id': '1',
          'name': 'Тестовый друг 1',
          'username': 'test_friend1',
          'streakDays': 5,
          'completedTopics': 10,
          'correctAnswers': 80,
          'avatar': '👤',
          'currentLeague': 'Бронза',
          'weeklyXP': 300,
          'isOnline': true,
        },
        {
          'id': '2',
          'name': 'Тестовый друг 2',
          'username': 'test_friend2',
          'streakDays': 12,
          'completedTopics': 18,
          'correctAnswers': 150,
          'avatar': '👤',
          'currentLeague': 'Серебро',
          'weeklyXP': 520,
          'isOnline': false,
        },
      ];
      _friendsCount = _friendsList.length;
    });
  }

  // Новый метод: загрузка данных достижений как на AchievementsScreen
  Future<void> _loadAchievementsData() async {
    try {
      // Имитируем загрузку данных как в AchievementsScreen
      final achievementsData = await _simulateAchievementsApiCall();

      if (mounted) {
        setState(() {
          _achievementsList = achievementsData;
          _totalAchievements = achievementsData.length;
          _achievementsCompleted = achievementsData.where((a) => a['isUnlocked'] == true).length;
        });
      }

      print('✅ Loaded achievements: $_achievementsCompleted/$_totalAchievements');

    } catch (e) {
      print('❌ Error loading achievements data: $e');
      // Fallback: создаем тестовые данные достижений
      _createMockAchievementsData();
    }
  }

  // Метод-заглушка для имитации API вызова достижений
  Future<List<Map<String, dynamic>>> _simulateAchievementsApiCall() async {
    await Future.delayed(Duration(milliseconds: 100));

    // Возвращаем тестовые данные достижений (как на AchievementsScreen)
    return [
      // Tests and learning
      {
        'id': 'first_test',
        'name': 'Первый шаг',
        'description': 'Пройдите первый тест',
        'imageAsset': '🎯',
        'requiredValue': 1,
        'currentValue': _completedTopics >= 1 ? 1 : 0,
        'type': 'testsCompleted',
        'isUnlocked': _completedTopics >= 1,
      },
      {
        'id': 'test_master',
        'name': 'Мастер тестов',
        'description': 'Пройдите 10 тестов',
        'imageAsset': '📚',
        'requiredValue': 10,
        'currentValue': _completedTopics,
        'type': 'testsCompleted',
        'isUnlocked': _completedTopics >= 10,
      },
      {
        'id': 'test_expert',
        'name': 'Эксперт тестов',
        'description': 'Пройдите 50 тестов',
        'imageAsset': '🏆',
        'requiredValue': 50,
        'currentValue': _completedTopics,
        'type': 'testsCompleted',
        'isUnlocked': _completedTopics >= 50,
      },
      {
        'id': 'test_legend',
        'name': 'Легенда тестов',
        'description': 'Пройдите 100 тестов',
        'imageAsset': '👑',
        'requiredValue': 100,
        'currentValue': _completedTopics,
        'type': 'testsCompleted',
        'isUnlocked': _completedTopics >= 100,
      },

      // Streaks
      {
        'id': 'streak_3',
        'name': 'Начало пути',
        'description': 'Занимайтесь 3 дня подряд',
        'imageAsset': '🔥',
        'requiredValue': 3,
        'currentValue': _userStats.streakDays,
        'type': 'streakDays',
        'isUnlocked': _userStats.streakDays >= 3,
      },
      {
        'id': 'streak_7',
        'name': 'Неделя силы',
        'description': 'Занимайтесь 7 дней подряд',
        'imageAsset': '💪',
        'requiredValue': 7,
        'currentValue': _userStats.streakDays,
        'type': 'streakDays',
        'isUnlocked': _userStats.streakDays >= 7,
      },
      {
        'id': 'streak_14',
        'name': 'Две недели',
        'description': 'Занимайтесь 14 дней подряд',
        'imageAsset': '🌟',
        'requiredValue': 14,
        'currentValue': _userStats.streakDays,
        'type': 'streakDays',
        'isUnlocked': _userStats.streakDays >= 14,
      },
      {
        'id': 'streak_30',
        'name': 'Месяц дисциплины',
        'description': 'Занимайтесь 30 дней подряд',
        'imageAsset': '🎖️',
        'requiredValue': 30,
        'currentValue': _userStats.streakDays,
        'type': 'streakDays',
        'isUnlocked': _userStats.streakDays >= 30,
      },
      {
        'id': 'streak_90',
        'name': 'Чемпион квартала',
        'description': 'Занимайтесь 90 дней подряд',
        'imageAsset': '🏅',
        'requiredValue': 90,
        'currentValue': _userStats.streakDays,
        'type': 'streakDays',
        'isUnlocked': _userStats.streakDays >= 90,
      },

      // XP and leagues
      {
        'id': 'knowledge_seeker',
        'name': 'Искатель знаний',
        'description': 'Заработайте 1000 XP',
        'imageAsset': '🔍',
        'requiredValue': 1000,
        'currentValue': _totalXP,
        'type': 'totalXP',
        'isUnlocked': _totalXP >= 1000,
      },
      {
        'id': 'wisdom_keeper',
        'name': 'Хранитель мудрости',
        'description': 'Заработайте 5000 XP',
        'imageAsset': '📖',
        'requiredValue': 5000,
        'currentValue': _totalXP,
        'type': 'totalXP',
        'isUnlocked': _totalXP >= 5000,
      },
      {
        'id': 'knowledge_master',
        'name': 'Мастер знаний',
        'description': 'Заработайте 10000 XP',
        'imageAsset': '🎇',
        'requiredValue': 10000,
        'currentValue': _totalXP,
        'type': 'totalXP',
        'isUnlocked': _totalXP >= 10000,
      },
      {
        'id': 'bronze_league',
        'name': 'Бронзовый боец',
        'description': 'Достигните Бронзовой лиги',
        'imageAsset': '🥉',
        'requiredValue': 1,
        'currentValue': _isLeagueAchieved('Бронза') ? 1 : 0,
        'type': 'league',
        'isUnlocked': _isLeagueAchieved('Бронза'),
      },
      {
        'id': 'silver_league',
        'name': 'Серебряный стратег',
        'description': 'Достигните Серебряной лиги',
        'imageAsset': '🥈',
        'requiredValue': 1,
        'currentValue': _isLeagueAchieved('Серебро') ? 1 : 0,
        'type': 'league',
        'isUnlocked': _isLeagueAchieved('Серебро'),
      },
      {
        'id': 'gold_league',
        'name': 'Золотой чемпион',
        'description': 'Достигните Золотой лиги',
        'imageAsset': '🥇',
        'requiredValue': 1,
        'currentValue': _isLeagueAchieved('Золото') ? 1 : 0,
        'type': 'league',
        'isUnlocked': _isLeagueAchieved('Золото'),
      },
      {
        'id': 'platinum_league',
        'name': 'Платиновый гений',
        'description': 'Достигните Платиновой лиги',
        'imageAsset': '💎',
        'requiredValue': 1,
        'currentValue': _isLeagueAchieved('Платина') ? 1 : 0,
        'type': 'league',
        'isUnlocked': _isLeagueAchieved('Платина'),
      },
      {
        'id': 'diamond_league',
        'name': 'Бриллиантовый мастер',
        'description': 'Достигните Бриллиантовой лиги',
        'imageAsset': '💠',
        'requiredValue': 1,
        'currentValue': _isLeagueAchieved('Бриллиант') ? 1 : 0,
        'type': 'league',
        'isUnlocked': _isLeagueAchieved('Бриллиант'),
      },

      // Correct answers
      {
        'id': 'correct_100',
        'name': 'Точный ответ',
        'description': 'Дайте 100 правильных ответов',
        'imageAsset': '✅',
        'requiredValue': 100,
        'currentValue': _correctAnswers,
        'type': 'correctAnswers',
        'isUnlocked': _correctAnswers >= 100,
      },
      {
        'id': 'correct_500',
        'name': 'Эрудит',
        'description': 'Дайте 500 правильных ответов',
        'imageAsset': '📝',
        'requiredValue': 500,
        'currentValue': _correctAnswers,
        'type': 'correctAnswers',
        'isUnlocked': _correctAnswers >= 500,
      },
      {
        'id': 'correct_1000',
        'name': 'Знаток',
        'description': 'Дайте 1000 правильных ответов',
        'imageAsset': '🏅',
        'requiredValue': 1000,
        'currentValue': _correctAnswers,
        'type': 'correctAnswers',
        'isUnlocked': _correctAnswers >= 1000,
      },
      {
        'id': 'correct_5000',
        'name': 'Ходячая энциклопедия',
        'description': 'Дайте 5000 правильных ответов',
        'imageAsset': '🎓',
        'requiredValue': 5000,
        'currentValue': _correctAnswers,
        'type': 'correctAnswers',
        'isUnlocked': _correctAnswers >= 5000,
      },
    ];
  }

  bool _isLeagueAchieved(String league) {
    final leagueOrder = ['Новичок', 'Бронза', 'Серебро', 'Золото', 'Платина', 'Бриллиант'];
    final currentIndex = leagueOrder.indexOf(_currentLeague);
    final targetIndex = leagueOrder.indexOf(league);
    return currentIndex >= targetIndex;
  }

  void _createMockAchievementsData() {
    setState(() {
      _achievementsList = [
        {
          'id': 'first_test',
          'name': 'Первый шаг',
          'description': 'Пройдите первый тест',
          'imageAsset': '🎯',
          'requiredValue': 1,
          'currentValue': 1,
          'type': 'testsCompleted',
          'isUnlocked': true,
        },
        {
          'id': 'streak_3',
          'name': 'Начало пути',
          'description': 'Занимайтесь 3 дня подряд',
          'imageAsset': '🔥',
          'requiredValue': 3,
          'currentValue': _userStats.streakDays,
          'type': 'streakDays',
          'isUnlocked': _userStats.streakDays >= 3,
        },
        {
          'id': 'correct_100',
          'name': 'Точный ответ',
          'description': 'Дайте 100 правильных ответов',
          'imageAsset': '✅',
          'requiredValue': 100,
          'currentValue': _correctAnswers,
          'type': 'correctAnswers',
          'isUnlocked': _correctAnswers >= 100,
        },
      ];
      _totalAchievements = 33; // Общее количество как на AchievementsScreen
      _achievementsCompleted = _achievementsList.where((a) => a['isUnlocked'] == true).length;
    });
  }

  Future<void> _loadSelectedSubjects() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedSubjects = prefs.getStringList('selectedSubjects');

      if (savedSubjects != null && savedSubjects.isNotEmpty) {
        setState(() {
          _selectedSubjects = savedSubjects;
        });
      } else {
        final allSubjects = _getAllSubjects();
        setState(() {
          _selectedSubjects = allSubjects;
        });
      }
    } catch (e) {
      print('❌ Error loading selected subjects: $e');
    }
  }

  void _calculateSubjectProgress() {
    final progress = <String, double>{};

    // Получаем все предметы из данных
    final subjectsByGrade = getSubjectsByGrade(context);
    final allSubjects = <String>{};

    for (final grade in subjectsByGrade.keys) {
      final subjects = subjectsByGrade[grade] ?? [];
      for (final subject in subjects) {
        allSubjects.add(subject.name);
      }
    }

    // Для каждого предмета считаем прогресс
    for (final subjectName in allSubjects) {
      if (_userStats.topicProgress.containsKey(subjectName)) {
        final topics = _userStats.topicProgress[subjectName] ?? {};
        final totalTopics = _getTotalTopicsForSubject(subjectName);

        if (totalTopics > 0) {
          final completedTopics = topics.length;
          progress[subjectName] = completedTopics / totalTopics;
        } else {
          progress[subjectName] = 0.0;
        }
      } else {
        progress[subjectName] = 0.0;
      }
    }

    if (mounted) {
      setState(() {
        _subjectProgress = progress;
      });
    }
  }

  int _getTotalTopicsForSubject(String subjectName) {
    final subjectsByGrade = getSubjectsByGrade(context);
    int totalTopics = 0;

    for (final grade in subjectsByGrade.keys) {
      final subjects = subjectsByGrade[grade] ?? [];
      for (final subject in subjects) {
        if (subject.name == subjectName) {
          final topics = subject.topicsByGrade[grade] ?? [];
          totalTopics += topics.length;
        }
      }
    }

    return totalTopics;
  }

  List<String> _getAllSubjects() {
    final allSubjects = <String>{};
    final subjectsByGrade = getSubjectsByGrade(context);
    for (final grade in subjectsByGrade.keys) {
      final subjects = subjectsByGrade[grade] ?? [];
      for (final subject in subjects) {
        allSubjects.add(subject.name);
      }
    }
    return allSubjects.toList();
  }

  bool _isPhotoAvatar() {
    return _avatar.startsWith('/') || _avatar.contains('.');
  }

  bool _isDefaultAvatar() {
    return !_isPhotoAvatar() && _avatar == '👤';
  }

  String _formatRegistrationDate() {
    if (_registrationDate == null) return 'Неизвестно';
    final formatter = DateFormat('dd.MM.yyyy');
    return 'На EduPeak с ${formatter.format(_registrationDate!)}';
  }

  Widget _buildAvatar() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProfileEditorScreen(
              currentAvatar: _avatar,
              onAvatarUpdate: (newAvatar) {
                setState(() {
                  _avatar = newAvatar;
                });
                UserDataStorage.saveAvatar(newAvatar);
              },
              onUsernameUpdate: (newUsername) {
                setState(() {
                  _username = newUsername;
                });
                UserDataStorage.saveUsername(newUsername);
              },
              onBottomNavTap: widget.onBottomNavTap,
              currentIndex: widget.currentIndex,
            ),
          ),
        ).then((_) => _loadUserData());
      },
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.15),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: _isPhotoAvatar()
                ? ClipOval(
              child: Image.file(
                File(_avatar),
                fit: BoxFit.cover,
                width: 120,
                height: 120,
                errorBuilder: (context, error, stackTrace) {
                  return _buildDefaultAvatarIcon();
                },
              ),
            )
                : _isDefaultAvatar()
                ? _buildDefaultAvatarIcon()
                : Center(
              child: Text(
                _avatar,
                style: TextStyle(
                  fontSize: 48,
                ),
              ),
            ),
          ),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(
              Icons.edit_rounded,
              color: Colors.white,
              size: 18,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDefaultAvatarIcon() {
    return Center(
      child: Icon(
        Icons.person_rounded,
        color: Theme.of(context).colorScheme.onPrimaryContainer,
        size: 60,
      ),
    );
  }

  Widget _buildFriendsCard() {
    return GestureDetector(
      onTap: _openFriendsScreen,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceVariant,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Theme.of(context).colorScheme.outline.withOpacity(0.1),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.people_rounded,
              size: 18,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
            const SizedBox(width: 8),
            Text(
              '$_friendsCount',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              'друзей',
              style: TextStyle(
                fontSize: 14,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.chevron_right_rounded,
              size: 18,
              color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.6),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubjectChip(String subject) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Text(
        subject,
        style: TextStyle(
          fontSize: 14,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
    VoidCallback? onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 20,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                value,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubjectProgressBar(String subjectName, double progress) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                subjectName,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              '${(progress * 100).round()}%',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        LinearProgressIndicator(
          value: progress,
          backgroundColor: Theme.of(context).colorScheme.surfaceVariant,
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(8),
          minHeight: 10,
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  List<Widget> _getTopSubjectsByProgress(int count) {
    if (_subjectProgress.isEmpty) return [];

    // Создаем список записей
    final entries = _subjectProgress.entries.toList();

    // Сортируем по убыванию прогресса
    entries.sort((a, b) => b.value.compareTo(a.value));

    // Берем нужное количество
    final topEntries = entries.take(count).toList();

    // Преобразуем в виджеты
    return topEntries.map((entry) => _buildSubjectProgressBar(entry.key, entry.value)).toList();
  }

  void _openStatisticsScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatisticsScreen(userStats: _userStats),
      ),
    );
  }

  void _openAchievementsScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AchievementsScreen(),
      ),
    ).then((_) {
      // После возврата из AchievementsScreen обновляем данные
      _loadAchievementsData();
    });
  }

  void _openFriendsScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FriendsScreen(),
      ),
    ).then((_) {
      // После возврата из FriendsScreen обновляем количество друзей
      _loadFriendsData();
    });
  }

  void _openLeagueScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EduLeagueScreen(),
      ),
    );
  }

  void _openStreakScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StreakScreen(
          dailyActivity: _dailyActivity,
          streakDays: _userStats.streakDays,
        ),
      ),
    );
  }

  void _openXPScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => XPScreen(
          dailyXP: _dailyXP,
        ),
      ),
    );
  }

  void _openSettingsScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SettingsScreen(onLogout: widget.onLogout),
      ),
    );
  }

  IconData _getLeagueIcon() {
    switch (_currentLeague) {
      case 'Бриллиант': return Icons.diamond_rounded;
      case 'Платина': return Icons.lens_rounded;
      case 'Золото': return Icons.lens_rounded;
      case 'Серебро': return Icons.lens_rounded;
      case 'Бронза': return Icons.lens_rounded;
      default: return Icons.lens_rounded;
    }
  }

  Color _getLeagueColor() {
    switch (_currentLeague) {
      case 'Бриллиант': return Color(0xFFB9F2FF);
      case 'Платина': return Color(0xFFE5E4E2);
      case 'Золото': return Color(0xFFFFD700);
      case 'Серебро': return Color(0xFFC0C0C0);
      case 'Бронза': return Color(0xFFCD7F32);
      default: return Theme.of(context).colorScheme.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final appLocalizations = AppLocalizations.of(context)!;
    final progressPercentage = _totalAchievements > 0
        ? (_achievementsCompleted / _totalAchievements) * 100
        : 0;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Заголовок и настройки
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    appLocalizations.profile,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.settings_rounded,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                    onPressed: _openSettingsScreen,
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Аватар и основная информация
              Center(
                child: Column(
                  children: [
                    _buildAvatar(),
                    const SizedBox(height: 16),
                    Text(
                      _username.isNotEmpty ? _username : 'Без имени',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _formatRegistrationDate(),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildFriendsCard(),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              // Изучаемые предметы
              if (_selectedSubjects.isNotEmpty)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Изучаемые предметы',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 40,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: _selectedSubjects.length,
                        itemBuilder: (context, index) {
                          return _buildSubjectChip(_selectedSubjects[index]);
                        },
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 32),

              // Статистика в 4 квадратах
              Text(
                'Моя статистика',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  _buildStatCard(
                    icon: Icons.local_fire_department_rounded,
                    value: '${_userStats.streakDays}',
                    label: 'Дней подряд',
                    color: Colors.orange,
                    onTap: _openStreakScreen,
                  ),
                  const SizedBox(width: 12),
                  _buildStatCard(
                    icon: Icons.star_rounded,
                    value: '$_totalXP',
                    label: 'Всего опыта',
                    color: Colors.blue,
                    onTap: _openXPScreen,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _buildStatCard(
                    icon: Icons.subject_rounded,
                    value: _mostPopularSubject.split(' ')[0],
                    label: 'Лучший предмет',
                    color: Colors.green,
                    onTap: _openStatisticsScreen,
                  ),
                  const SizedBox(width: 12),
                  _buildStatCard(
                    icon: _getLeagueIcon(),
                    value: _currentLeague,
                    label: 'Текущая лига',
                    color: _getLeagueColor(),
                    onTap: _openLeagueScreen,
                  ),
                ],
              ),
              const SizedBox(height: 32),

              // Подробная статистика с прогресс-барами по предметам
              GestureDetector(
                onTap: _openStatisticsScreen,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              Icons.analytics_rounded,
                              color: Theme.of(context).colorScheme.primary,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Подробная статистика',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.chevron_right_rounded,
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Прогресс-бары по предметам (первые 3 предмета по прогрессу)
                      if (_subjectProgress.isNotEmpty)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Прогресс по предметам:',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w500,
                                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.8),
                              ),
                            ),
                            const SizedBox(height: 12),

                            // Сортируем предметы по прогрессу и берем топ-3
                            ..._getTopSubjectsByProgress(3),

                            if (_subjectProgress.length > 3)
                              GestureDetector(
                                onTap: _openStatisticsScreen,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Показать все предметы',
                                        style: TextStyle(
                                          color: Theme.of(context).colorScheme.primary,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Icon(
                                        Icons.chevron_right_rounded,
                                        color: Theme.of(context).colorScheme.primary,
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        )
                      else
                        Text(
                          'Начните изучать темы, чтобы увидеть прогресс',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Достижения (с реальными данными как на AchievementsScreen)
              GestureDetector(
                onTap: _openAchievementsScreen,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              Icons.emoji_events_rounded,
                              color: Colors.amber,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Достижения',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.chevron_right_rounded,
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Прогресс достижений',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              Text(
                                '$_achievementsCompleted/$_totalAchievements',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          LinearProgressIndicator(
                            value: _totalAchievements > 0 ? (_achievementsCompleted / _totalAchievements) : 0,
                            backgroundColor: Theme.of(context).colorScheme.surfaceVariant,
                            color: Theme.of(context).colorScheme.primary,
                            borderRadius: BorderRadius.circular(8),
                            minHeight: 12,
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${progressPercentage.round()}% завершено',
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                                ),
                              ),
                              Text(
                                '${_totalAchievements - _achievementsCompleted} осталось',
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                                ),
                              ),
                            ],
                          ),

                          // Примеры ближайших достижений
                          if (_achievementsList.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Ближайшие достижения:',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  ..._achievementsList
                                      .where((a) => !a['isUnlocked'] && a['currentValue'] > 0)
                                      .take(2)
                                      .map((achievement) => Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: Row(
                                      children: [
                                        Text(
                                          achievement['imageAsset'],
                                          style: TextStyle(fontSize: 20),
                                        ),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                achievement['name'],
                                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                '${achievement['currentValue']}/${achievement['requiredValue']}',
                                                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ))
                                      .toList(),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}