class UserStats {
  int streakDays;
  DateTime lastActivity;
  Map<String, Map<String, int>> topicProgress;
  Map<String, bool> dailyCompletion;
  String username;

  UserStats({
    required this.streakDays,
    required this.lastActivity,
    required this.topicProgress,
    required this.dailyCompletion,
    required this.username,
  });

  // Ваши методы сериализации
  Map<String, dynamic> toJson() {
    return {
      'streakDays': streakDays,
      'lastActivity': lastActivity.toIso8601String(),
      'topicProgress': topicProgress,
      'dailyCompletion': dailyCompletion,
      'username': username,
    };
  }

  factory UserStats.fromJson(Map<String, dynamic> json) {
    // Безопасный парсинг topicProgress
    Map<String, Map<String, int>> topicProgress = {};
    try {
      final progressData = json['topicProgress'];
      if (progressData is Map) {
        progressData.forEach((subject, topics) {
          if (topics is Map) {
            final topicMap = <String, int>{};
            topics.forEach((topic, value) {
              if (value is int) {
                topicMap[topic.toString()] = value;
              }
            });
            topicProgress[subject.toString()] = topicMap;
          }
        });
      }
    } catch (e) {
      print('Error parsing topicProgress: $e');
      topicProgress = {};
    }

    // Безопасный парсинг dailyCompletion
    Map<String, bool> dailyCompletion = {};
    try {
      final completionData = json['dailyCompletion'];
      if (completionData is Map) {
        completionData.forEach((date, value) {
          if (value is bool) {
            dailyCompletion[date.toString()] = value;
          }
        });
      }
    } catch (e) {
      print('Error parsing dailyCompletion: $e');
      dailyCompletion = {};
    }

    return UserStats(
      streakDays: (json['streakDays'] as int?) ?? 0,
      lastActivity: DateTime.parse(json['lastActivity'] as String? ?? DateTime.now().toIso8601String()),
      topicProgress: topicProgress,
      dailyCompletion: dailyCompletion,
      username: (json['username'] as String?) ?? '',
    );
  }

  // Ваш метод для сброса прогресса
  void resetProgress() {
    streakDays = 0;
    topicProgress.clear();
    dailyCompletion.clear();
    lastActivity = DateTime.now();
  }

  // Мои методы для работы с ID тем

  // Метод для получения прогресса по ID темы
  int getTopicProgress(String subjectId, String topicId) {
    return topicProgress[subjectId]?[topicId] ?? 0;
  }

  // Метод для обновления прогресса с ID
  UserStats updateTopicProgress(String subjectId, String topicId, int correctAnswers) {
    final newTopicProgress = Map<String, Map<String, int>>.from(topicProgress);
    newTopicProgress[subjectId] ??= {};
    newTopicProgress[subjectId]![topicId] = correctAnswers;

    return UserStats(
      streakDays: streakDays,
      lastActivity: lastActivity,
      topicProgress: newTopicProgress,
      dailyCompletion: dailyCompletion,
      username: username,
    );
  }

  // Метод для копирования с обновленными полями
  UserStats copyWith({
    int? streakDays,
    DateTime? lastActivity,
    Map<String, Map<String, int>>? topicProgress,
    Map<String, bool>? dailyCompletion,
    String? username,
  }) {
    return UserStats(
      streakDays: streakDays ?? this.streakDays,
      lastActivity: lastActivity ?? this.lastActivity,
      topicProgress: topicProgress ?? this.topicProgress,
      dailyCompletion: dailyCompletion ?? this.dailyCompletion,
      username: username ?? this.username,
    );
  }

  // Метод для проверки завершения темы по ID
  bool isTopicCompleted(String subjectId, String topicId, int totalQuestions) {
    final correctAnswers = getTopicProgress(subjectId, topicId);
    return correctAnswers >= totalQuestions;
  }

  // Метод для получения всех завершенных тем
  Map<String, List<String>> getCompletedTopics() {
    final completed = <String, List<String>>{};

    topicProgress.forEach((subjectId, topics) {
      completed[subjectId] = topics.keys.toList();
    });

    return completed;
  }

  // Метод для получения общего количества завершенных тем
  int get totalCompletedTopics {
    int total = 0;
    topicProgress.forEach((subjectId, topics) {
      total += topics.length;
    });
    return total;
  }

  // Метод для получения общего количества правильных ответов
  int get totalCorrectAnswers {
    int total = 0;
    topicProgress.forEach((subjectId, topics) {
      topics.forEach((topicId, correctAnswers) {
        total += correctAnswers;
      });
    });
    return total;
  }

  // Метод для обновления серии дней
  UserStats updateStreak() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final lastActivityDay = DateTime(lastActivity.year, lastActivity.month, lastActivity.day);

    final difference = today.difference(lastActivityDay).inDays;

    int newStreakDays = streakDays;

    if (difference == 1) {
      // Последовательные дни
      newStreakDays = streakDays + 1;
    } else if (difference > 1) {
      // Пропущенные дни - сброс серии
      newStreakDays = 1;
    }
    // Если difference == 0 - тот же день, оставляем текущую серию

    return copyWith(
      streakDays: newStreakDays,
      lastActivity: now,
    );
  }

  // Метод для обновления ежедневного выполнения
  UserStats updateDailyCompletion() {
    final today = DateTime.now().toIso8601String().split('T')[0];
    final newDailyCompletion = Map<String, bool>.from(dailyCompletion);
    newDailyCompletion[today] = true;

    return copyWith(dailyCompletion: newDailyCompletion);
  }

  // Метод для проверки, выполнено ли сегодня
  bool get todayCompleted {
    final today = DateTime.now().toIso8601String().split('T')[0];
    return dailyCompletion[today] ?? false;
  }
}