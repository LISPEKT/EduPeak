class Question {
  final String text;
  final List<String> options;
  final int correctIndex;
  final String explanation;
  final String answerType; // 'choice' или 'text'

  const Question({
    required this.text,
    required this.options,
    required this.correctIndex,
    required this.explanation,
    required this.answerType,
  });

  Question copyWith({
    String? text,
    List<String>? options,
    int? correctIndex,
    String? explanation,
    String? answerType,
  }) {
    return Question(
      text: text ?? this.text,
      options: options ?? this.options,
      correctIndex: correctIndex ?? this.correctIndex,
      explanation: explanation ?? this.explanation,
      answerType: answerType ?? this.answerType,
    );
  }
}