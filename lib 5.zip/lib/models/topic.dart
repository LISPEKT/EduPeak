import 'question.dart';

class Topic {
  final String id;
  final String name;
  final String imageAsset;
  final String description;
  final String explanation;
  final List<Question> questions;

  const Topic({
    required this.id,
    required this.name,
    required this.imageAsset,
    required this.description,
    required this.explanation,
    required this.questions,
  });

  // Добавьте метод для копирования с другим названием
  Topic copyWith({
    String? name,
    String? description,
    String? explanation,
  }) {
    return Topic(
      id: id,
      name: name ?? this.name,
      imageAsset: imageAsset,
      description: description ?? this.description,
      explanation: explanation ?? this.explanation,
      questions: questions,
    );
  }
}