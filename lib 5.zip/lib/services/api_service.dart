// lib/services/api_service.dart
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  late Dio _dio;
  final String _baseUrl = 'http://46.254.19.119:8000';
  bool _isInitialized = false;
  String? _csrfToken;
  String? _sessionCookie;

  // Статические методы для совместимости со старым кодом
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isLoggedIn') ?? false;
  }

  static Future<bool> checkServerAvailability() async {
    return await ApiService()._checkServerAvailability();
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    return await ApiService()._login(email, password);
  }

  static Future<Map<String, dynamic>> register(String name, String email, String password) async {
    return await ApiService()._register(name, email, password);
  }

  static Future<void> logout() async {
    await ApiService()._logout();
  }

  static Future<void> updateTopicProgress(String subject, String topicName, int correctAnswers) async {
    await ApiService()._updateTopicProgress(subject, topicName, correctAnswers);
  }

  // ИСПРАВЛЕНО: Убрали дублирующий статический метод
  static Future<Map<String, dynamic>?> getUserProgress() async {
    final apiService = ApiService();
    await apiService.initialize();
    return await apiService._getUserProgress();
  }

  static Future<Map<String, dynamic>> updateAvatar(String imagePath) async {
    return await ApiService()._updateAvatar(imagePath);
  }

  static Future<Map<String, dynamic>> discoverEndpoints() async {
    return await ApiService()._discoverEndpoints();
  }

  // Реализации методов
  Future<void> initialize() async {
    if (_isInitialized) return;

    _dio = Dio(BaseOptions(
      baseUrl: _baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
      },
    ));

    // Добавляем перехватчик для обработки cookies
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        // Загружаем cookies перед каждым запросом
        await _loadCookies();
        if (_sessionCookie != null) {
          options.headers['cookie'] = _sessionCookie;
        }
        if (_csrfToken != null && (options.method == 'POST' || options.method == 'PUT' || options.method == 'PATCH')) {
          if (options.data is Map) {
            (options.data as Map)['_token'] = _csrfToken;
          } else if (options.data is String) {
            // Для form-data добавляем токен
            final data = options.data as String;
            if (!data.contains('_token=')) {
              options.data = '$data&_token=$_csrfToken';
            }
          }
        }
        handler.next(options);
      },
      onResponse: (response, handler) {
        // Сохраняем cookies из ответа
        _saveCookiesFromResponse(response);
        handler.next(response);
      },
    ));

    _dio.interceptors.add(LogInterceptor(
      request: true,
      requestBody: true,
      responseBody: true,
      requestHeader: true,
      responseHeader: true,
    ));

    await _loadCookies();
    _isInitialized = true;
    print('✅ Dio initialized with baseUrl: $_baseUrl');
  }

  Future<bool> _checkServerAvailability() async {
    try {
      if (!_isInitialized) await initialize();

      final response = await _dio.get('/');
      print('🌐 Server response status: ${response.statusCode}');
      return response.statusCode == 200;
    } catch (e) {
      print('❌ Server unavailable: $e');
      return false;
    }
  }

  Future<String?> _getCsrfToken() async {
    try {
      if (!_isInitialized) await initialize();

      final response = await _dio.get('/profile');
      final html = response.data.toString();

      final tokenPattern = RegExp(r'name="_token" value="([^"]+)"');
      final match = tokenPattern.firstMatch(html);

      if (match != null) {
        final token = match.group(1);
        print('✅ CSRF Token found: $token');
        _csrfToken = token;
        await _saveCookies();
        return token;
      }

      print('❌ CSRF Token not found');
      return null;
    } catch (e) {
      print('❌ Error getting CSRF token: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>> _login(String email, String password) async {
    try {
      if (!_isInitialized) await initialize();

      // Получаем свежий CSRF токен
      final csrfToken = await _getCsrfToken();
      if (csrfToken == null) {
        throw Exception('Не удалось получить CSRF токен');
      }

      final formData = {
        '_token': csrfToken,
        'email': email,
        'password': password,
      };

      print('🔐 Login attempt with email: $email');

      final response = await _dio.post(
        '/login',
        data: formData,
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': _baseUrl,
            'Referer': '$_baseUrl/login',
          },
          followRedirects: false, // Не следовать редиректам автоматически
          validateStatus: (status) => status! < 500, // Принимать статусы < 500
        ),
      );

      print('📡 Login response status: ${response.statusCode}');
      print('📡 Login response headers: ${response.headers}');

      // Проверяем редирект на профиль (успешный вход)
      if (response.statusCode == 302) {
        final location = response.headers['location']?.first;
        if (location != null && location.contains('/profile')) {
          await _saveCookies();

          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('isLoggedIn', true);
          await prefs.setString('userEmail', email);

          return {'success': true, 'message': 'Вход выполнен успешно'};
        }
      }

      // Если нет редиректа, проверяем содержимое ответа
      final responseText = response.data.toString();
      if (responseText.contains('Неверный email или пароль') ||
          responseText.contains('Invalid credentials')) {
        return {'success': false, 'message': 'Неверный email или пароль'};
      }

      return {'success': false, 'message': 'Ошибка входа. Проверьте данные.'};
    } catch (e) {
      print('❌ Login error: $e');

      if (e is DioException) {
        final response = e.response;
        if (response != null) {
          final responseText = response.data.toString();
          if (responseText.contains('Неверный email или пароль') ||
              responseText.contains('Invalid credentials')) {
            return {'success': false, 'message': 'Неверный email или пароль'};
          }
        }
      }

      return {'success': false, 'message': 'Ошибка сети: $e'};
    }
  }

  Future<Map<String, dynamic>> _register(String name, String email, String password) async {
    try {
      if (!_isInitialized) await initialize();

      // Получаем свежий CSRF токен
      final csrfToken = await _getCsrfToken();
      if (csrfToken == null) {
        throw Exception('Не удалось получить CSRF токен');
      }

      final formData = {
        '_token': csrfToken,
        'name': name,
        'email': email,
        'password': password,
        'password_confirmation': password,
      };

      print('📝 Registration attempt with email: $email');

      final response = await _dio.post(
        '/register',
        data: formData,
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': _baseUrl,
            'Referer': '$_baseUrl/register',
          },
          followRedirects: false,
          validateStatus: (status) => status! < 500,
        ),
      );

      print('📡 Registration response status: ${response.statusCode}');

      // Проверяем редирект на профиль (успешная регистрация)
      if (response.statusCode == 302) {
        final location = response.headers['location']?.first;
        if (location != null && location.contains('/profile')) {
          await _saveCookies();

          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('isLoggedIn', true);
          await prefs.setString('userEmail', email);

          return {'success': true, 'message': 'Регистрация успешна'};
        }
      }

      // Проверяем ошибки валидации
      final responseText = response.data.toString();
      if (responseText.contains('email has already been taken') ||
          responseText.contains('Email уже используется')) {
        return {'success': false, 'message': 'Email уже используется'};
      }

      if (responseText.contains('password confirmation') ||
          responseText.contains('Пароли не совпадают')) {
        return {'success': false, 'message': 'Пароли не совпадают'};
      }

      return {'success': false, 'message': 'Ошибка регистрации. Проверьте данные.'};
    } catch (e) {
      print('❌ Registration error: $e');
      return {'success': false, 'message': 'Ошибка сети: $e'};
    }
  }

  Future<Map<String, dynamic>?> getProfile() async {
    try {
      if (!_isInitialized) await initialize();
      await _loadCookies();

      print('🔍 Checking authentication status...');

      // Пытаемся получить профиль с обработкой редиректов
      final response = await _dio.get(
        '/profile',
        options: Options(
          followRedirects: false,
          validateStatus: (status) => status! < 400,
        ),
      );

      print('📡 Profile response status: ${response.statusCode}');

      // Если редирект на логин - не авторизованы
      if (response.statusCode == 302) {
        final location = response.headers['location']?.first;
        if (location != null && location.contains('/login')) {
          print('❌ Not authenticated - redirect to login');
          return null;
        }
      }

      // Если успешный ответ - парсим профиль
      if (response.statusCode == 200) {
        final html = response.data.toString();
        return _parseUserDataFromHtml(html);
      }

      return null;
    } catch (e) {
      print('❌ Get profile error: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>> updateProfile(String name, String email) async {
    try {
      if (!_isInitialized) await initialize();

      // Получаем свежий CSRF токен
      final csrfToken = await _getCsrfToken();
      if (csrfToken == null) {
        throw Exception('Не удалось получить CSRF токен');
      }

      final formData = {
        '_token': csrfToken,
        'name': name,
        'email': email,
      };

      print('📝 Updating profile: $name, $email');

      final response = await _dio.post(
        '/profile/update',
        data: formData,
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': _baseUrl,
            'Referer': '$_baseUrl/profile',
          },
          followRedirects: false,
          validateStatus: (status) => status! < 500,
        ),
      );

      print('📡 Profile update response status: ${response.statusCode}');

      if (response.statusCode == 200 || response.statusCode == 302) {
        return {'success': true, 'message': 'Профиль успешно обновлен'};
      } else {
        return {'success': false, 'message': 'Ошибка обновления профиля'};
      }
    } catch (e) {
      print('❌ Profile update error: $e');

      // Если эндпоинт не существует, сохраняем локально
      if (e is DioException && e.response?.statusCode == 404) {
        print('⚠️ Profile update endpoint not found, saving locally only');
        return {
          'success': true,
          'message': 'Имя сохранено локально (сервер не поддерживает обновление)'
        };
      }

      return {
        'success': false,
        'message': 'Ошибка обновления профиля: $e'
      };
    }
  }

  Future<String?> downloadAvatar(String avatarUrl) async {
    try {
      if (!_isInitialized) await initialize();

      print('📥 Downloading avatar from: $avatarUrl');

      final response = await _dio.get(
        avatarUrl,
        options: Options(
          responseType: ResponseType.bytes,
          followRedirects: true,
          validateStatus: (status) => status! < 400,
        ),
      );

      if (response.statusCode == 200) {
        final appDir = await getApplicationDocumentsDirectory();
        final avatarDir = Directory('${appDir.path}/avatars');

        if (!await avatarDir.exists()) {
          await avatarDir.create(recursive: true);
        }

        final fileName = 'server_avatar_${DateTime.now().millisecondsSinceEpoch}.jpg';
        final filePath = '${avatarDir.path}/$fileName';

        final file = File(filePath);
        await file.writeAsBytes(response.data);

        print('✅ Avatar downloaded successfully: $filePath');
        return filePath;
      }

      return null;
    } catch (e) {
      print('❌ Avatar download error: $e');
      return null;
    }
  }

  Future<bool> checkServerLoginStatus() async {
    try {
      final profile = await getProfile();
      return profile != null;
    } catch (e) {
      print('❌ Server login check error: $e');
      return false;
    }
  }

  Future<void> _logout() async {
    try {
      if (!_isInitialized) await initialize();

      final csrfToken = await _getCsrfToken();
      if (csrfToken != null) {
        await _dio.post(
          '/logout',
          data: {'_token': csrfToken},
          options: Options(
            contentType: Headers.formUrlEncodedContentType,
            validateStatus: (status) => status! < 500,
          ),
        );
      }

      await _clearCookies();

      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', false);
      await prefs.remove('userEmail');

      print('✅ Logout successful');
    } catch (e) {
      print('❌ Logout error: $e');
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', false);
      await prefs.remove('userEmail');
    }
  }

  // Заглушки для методов, которые могут быть не реализованы на сервере
  Future<void> _updateTopicProgress(String subject, String topicName, int correctAnswers) async {
    // Локальное сохранение прогресса
    final prefs = await SharedPreferences.getInstance();
    final progressKey = 'progress_${subject}_$topicName';
    await prefs.setInt(progressKey, correctAnswers);
    print('✅ Progress saved locally: $subject - $topicName: $correctAnswers');
  }

  Future<Map<String, dynamic>?> _getUserProgress() async {
    // Локальное получение прогресса
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys().where((key) => key.startsWith('progress_')).toList();

    final progress = <String, Map<String, int>>{};
    for (final key in keys) {
      final parts = key.replaceFirst('progress_', '').split('_');
      if (parts.length >= 2) {
        final subject = parts[0];
        final topicName = parts.sublist(1).join('_');
        final correctAnswers = prefs.getInt(key) ?? 0;

        if (!progress.containsKey(subject)) {
          progress[subject] = {};
        }
        progress[subject]![topicName] = correctAnswers;
      }
    }

    return {'progress': progress};
  }

  Future<Map<String, dynamic>> _updateAvatar(String imagePath) async {
    try {
      if (!_isInitialized) await initialize();

      // Получаем свежий CSRF токен
      final csrfToken = await _getCsrfToken();
      if (csrfToken == null) {
        throw Exception('Не удалось получить CSRF токен');
      }

      print('🖼️ Uploading avatar: $imagePath');

      // Создаем FormData для загрузки файла
      final formData = FormData.fromMap({
        '_token': csrfToken,
        'avatar': await MultipartFile.fromFile(
          imagePath,
          filename: 'avatar_${DateTime.now().millisecondsSinceEpoch}.jpg',
        ),
      });

      final response = await _dio.post(
        '/profile/avatar',
        data: formData,
        options: Options(
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': _baseUrl,
            'Referer': '$_baseUrl/profile',
          },
          contentType: 'multipart/form-data',
          followRedirects: false,
          validateStatus: (status) => status! < 500,
        ),
      );

      print('📡 Avatar upload response status: ${response.statusCode}');

      if (response.statusCode == 200 || response.statusCode == 302) {
        // Успешная загрузка аватара
        print('✅ Avatar uploaded successfully to server');
        return {
          'success': true,
          'message': 'Аватар успешно обновлен на сервере',
          'avatar_url': _extractAvatarUrlFromResponse(response)
        };
      } else {
        print('❌ Avatar upload failed with status: ${response.statusCode}');
        return {
          'success': false,
          'message': 'Ошибка загрузки аватара на сервер'
        };
      }
    } catch (e) {
      print('❌ Avatar upload error: $e');

      // Если эндпоинт не существует, сохраняем локально
      if (e is DioException && e.response?.statusCode == 404) {
        print('⚠️ Avatar endpoint not found, saving locally only');
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user_avatar_path', imagePath);
        return {
          'success': true,
          'message': 'Аватар сохранен локально (сервер не поддерживает загрузку)'
        };
      }

      return {
        'success': false,
        'message': 'Ошибка загрузки аватара: $e'
      };
    }
  }

  String? _extractAvatarUrlFromResponse(Response response) {
    try {
      final responseText = response.data.toString();

      // Пытаемся найти URL аватара в ответе
      final avatarPattern = RegExp(r'src="([^"]*avatar[^"]*)"');
      final match = avatarPattern.firstMatch(responseText);

      if (match != null) {
        final avatarUrl = match.group(1);
        print('🖼️ Extracted avatar URL: $avatarUrl');
        return avatarUrl;
      }

      return null;
    } catch (e) {
      print('❌ Error extracting avatar URL: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>> _discoverEndpoints() async {
    // Проверка доступности эндпоинтов
    final endpoints = <String, bool>{};

    try {
      final response = await _dio.get('/');
      endpoints['/'] = response.statusCode == 200;
    } catch (e) {
      endpoints['/'] = false;
    }

    try {
      final response = await _dio.get('/login');
      endpoints['/login'] = response.statusCode == 200;
    } catch (e) {
      endpoints['/login'] = false;
    }

    try {
      final response = await _dio.get('/register');
      endpoints['/register'] = response.statusCode == 200;
    } catch (e) {
      endpoints['/register'] = false;
    }

    try {
      final response = await _dio.get('/profile');
      endpoints['/profile'] = response.statusCode == 200;
    } catch (e) {
      endpoints['/profile'] = false;
    }

    // Проверяем эндпоинт для загрузки аватара
    try {
      final response = await _dio.get('/profile/avatar');
      endpoints['/profile/avatar'] = response.statusCode == 200;
    } catch (e) {
      endpoints['/profile/avatar'] = false;
    }

    return {
      'success': true,
      'endpoints': endpoints,
      'message': 'Проверка эндпоинтов завершена'
    };
  }

  void _saveCookiesFromResponse(Response response) {
    final cookies = response.headers['set-cookie'];
    if (cookies != null) {
      for (final cookie in cookies) {
        if (cookie.contains('laravel-session')) {
          _sessionCookie = cookie.split(';').first;
        } else if (cookie.contains('XSRF-TOKEN')) {
          final tokenMatch = RegExp(r'XSRF-TOKEN=([^;]+)').firstMatch(cookie);
          if (tokenMatch != null) {
            _csrfToken = Uri.decodeComponent(tokenMatch.group(1)!);
          }
        }
      }
      _saveCookies();
    }
  }

  Future<void> _saveCookies() async {
    final prefs = await SharedPreferences.getInstance();
    if (_sessionCookie != null) {
      await prefs.setString('session_cookie', _sessionCookie!);
    }
    if (_csrfToken != null) {
      await prefs.setString('csrf_token', _csrfToken!);
    }
  }

  Future<void> _loadCookies() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionCookie = prefs.getString('session_cookie');
    _csrfToken = prefs.getString('csrf_token');

    print('🍪 Loaded cookies - Session: ${_sessionCookie != null ? "Yes" : "No"}, CSRF: ${_csrfToken != null ? "Yes" : "No"}');
  }

  Future<void> _clearCookies() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('session_cookie');
    await prefs.remove('csrf_token');
    _sessionCookie = null;
    _csrfToken = null;
  }

  Map<String, dynamic> _parseUserDataFromHtml(String html) {
    try {
      print('🔍 Parsing profile HTML...');

      // Логируем первые 500 символов HTML для отладки
      if (html.length > 500) {
        print('📄 HTML preview: ${html.substring(0, 500)}...');
      } else {
        print('📄 HTML: $html');
      }

      String name = 'Пользователь';
      String avatarUrl = '';

      // Пытаемся найти имя пользователя разными способами
      try {
        // Паттерн 1: Ищем в заголовках h1-h6
        final namePattern1 = RegExp(r'<h[1-6][^>]*>([^<]+)</h[1-6]>');
        // Паттерн 2: Ищем в div с классами содержащими name, user, profile
        final namePattern2 = RegExp(r'<div[^>]*class="[^"]*(name|user|profile)[^"]*"[^>]*>([^<]+)</div>');
        // Паттерн 3: Ищем в span с классами
        final namePattern3 = RegExp(r'<span[^>]*class="[^"]*(name|user)[^"]*"[^>]*>([^<]+)</span>');
        // Паттерн 4: Ищем после слова "Имя" или "Name"
        final namePattern4 = RegExp(r'[Ии]мя[^>]*>([^<]+)<');
        // Паттерн 5: Ищем текст который выглядит как имя (только буквы, пробелы, кириллица)
        final namePattern5 = RegExp(r'>([А-Яа-яA-Za-z\s]{2,30})<');

        // Собираем все возможные кандидаты
        final candidates = <String>[];

        for (final match in namePattern1.allMatches(html)) {
          candidates.add(match.group(1)!.trim());
        }
        for (final match in namePattern2.allMatches(html)) {
          if (match.groupCount >= 2) candidates.add(match.group(2)!.trim());
        }
        for (final match in namePattern3.allMatches(html)) {
          if (match.groupCount >= 2) candidates.add(match.group(2)!.trim());
        }
        for (final match in namePattern4.allMatches(html)) {
          candidates.add(match.group(1)!.trim());
        }
        for (final match in namePattern5.allMatches(html)) {
          candidates.add(match.group(1)!.trim());
        }

        // Фильтруем кандидатов
        for (final candidate in candidates) {
          if (candidate.isNotEmpty &&
              candidate.length > 1 &&
              candidate.length < 50 &&
              !candidate.contains('@') &&
              !candidate.contains('http') &&
              !candidate.contains('<') &&
              !candidate.contains('>') &&
              !['Профиль', 'Profile', 'Вход', 'Login', 'Выйти', 'Logout', 'Главная', 'Home']
                  .contains(candidate)) {
            name = candidate;
            print('✅ Found name: "$name"');
            break;
          }
        }
      } catch (e) {
        print('⚠️ Error parsing name: $e');
      }

      // Парсим аватар
      try {
        final avatarPatterns = [
          RegExp(r'<img[^>]*src="([^"]*avatar[^"]*)"', caseSensitive: false),
          RegExp(r'<img[^>]*src="([^"]*uploads[^"]*)"', caseSensitive: false),
          RegExp(r'<img[^>]*src="(/storage/[^"]*)"', caseSensitive: false),
          RegExp(r'<img[^>]*src="(.*\.(jpg|jpeg|png|gif|webp))"', caseSensitive: false),
        ];

        for (final pattern in avatarPatterns) {
          for (final match in pattern.allMatches(html)) {
            final candidate = match.group(1)!;
            if (candidate.isNotEmpty &&
                !candidate.contains('logo') &&
                !candidate.contains('icon') &&
                candidate.length > 10) {
              avatarUrl = candidate;
              print('✅ Found avatar URL: "$avatarUrl"');
              break;
            }
          }
          if (avatarUrl.isNotEmpty) break;
        }

        // Если URL относительный, делаем его абсолютным
        if (avatarUrl.isNotEmpty && avatarUrl.startsWith('/')) {
          avatarUrl = '$_baseUrl$avatarUrl';
          print('🔗 Converted to absolute URL: $avatarUrl');
        }
      } catch (e) {
        print('⚠️ Error parsing avatar: $e');
      }

      print('👤 Final parsed data - Name: "$name", Avatar: "$avatarUrl"');

      return {
        'name': name,
        'email': '',
        'avatar_url': avatarUrl,
        'streak': 0,
      };
    } catch (e) {
      print('❌ Error parsing user data: $e');
      return {
        'name': 'Пользователь',
        'email': '',
        'avatar_url': '',
        'streak': 0,
      };
    }
  }
}