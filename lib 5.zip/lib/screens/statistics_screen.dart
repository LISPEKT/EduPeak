import 'package:flutter/material.dart';
import '../models/user_stats.dart';
import '../data/subjects_data.dart';
import '../localization.dart';

class StatisticsScreen extends StatelessWidget {
  final UserStats userStats;

  const StatisticsScreen({super.key, required this.userStats});

  @override
  Widget build(BuildContext context) {
    final appLocalizations = AppLocalizations.of(context);
    final subjectsData = SubjectsData(); // Создаем экземпляр здесь

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(appLocalizations.statistics),
        backgroundColor: Theme.of(context).cardColor,
        foregroundColor: Theme.of(context).textTheme.bodyLarge?.color,
        elevation: 1,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Статистика по серии
            _StatCard(
              title: appLocalizations.daysInRow,
              value: '${userStats.streakDays}',
              icon: Icons.local_fire_department,
              color: Colors.orange,
            ),
            const SizedBox(height: 16),

            // Завершенные темы
            _StatCard(
              title: appLocalizations.completedTopicsCount,
              value: '${userStats.totalCompletedTopics}',
              icon: Icons.check_circle,
              color: Colors.green,
            ),
            const SizedBox(height: 16),

            // Правильные ответы
            _StatCard(
              title: appLocalizations.correctAnswersCount,
              value: '${userStats.totalCorrectAnswers}',
              icon: Icons.emoji_events,
              color: Colors.blue,
            ),
            const SizedBox(height: 24),

            // Прогресс по предметам
            Text(
              appLocalizations.progressBySubjects,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),

            Expanded(
              child: _buildSubjectProgress(context, subjectsData),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubjectProgress(BuildContext context, SubjectsData subjectsData) {
    if (userStats.topicProgress.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.analytics_outlined,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Нет данных о прогрессе',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      );
    }

    return ListView(
      children: userStats.topicProgress.entries.map((entry) {
        final subjectId = entry.key;
        final topics = entry.value;

        // Получаем локализованное название предмета
        final subjectName = _getLocalizedSubjectName(subjectId, context, subjectsData);
        final completedTopics = topics.length;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.school,
                color: Theme.of(context).primaryColor,
              ),
            ),
            title: Text(
              subjectName,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            subtitle: Text(
              'Завершено тем: $completedTopics',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            trailing: Text(
              '$completedTopics',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  String _getLocalizedSubjectName(String subjectId, BuildContext context, SubjectsData subjectsData) {
    // Убираем суффикс класса из subjectId
    final subjectName = subjectId.replaceAll(RegExp(r'_\d+$'), '');
    return subjectsData.getLocalizedSubjectName(subjectName, context);
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}