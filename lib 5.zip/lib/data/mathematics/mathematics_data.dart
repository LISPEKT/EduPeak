import '../../models/subject.dart';
import '../../models/topic.dart';
import '../../models/question.dart';

// Математика 1 класс
final List<Subject> mathematicsSubjects1 = [
  Subject(
    name: 'Математика',
    topicsByGrade: {
      1: [
        Topic(
          name: 'Счёт до 10',
          imageAsset: '🔢',
          description: 'Учимся считать от 1 до 10',
          explanation: 'Цифры помогают нам считать предметы.',
          questions: [
            Question(
              text: 'Сколько яблок на картинке? 🍎🍎🍎',
              options: ['2', '3', '4', '5', '1'],
              correctIndex: 1,
              explanation: 'Три яблока - это цифра 3',
            ),
            Question(
              text: 'Какая цифра идёт после 5?',
              options: ['4', '6', '7', '3', '8'],
              correctIndex: 1,
              explanation: 'После пяти идёт шесть',
            ),
            Question(
              text: 'Посчитай: 2 + 3 = ?',
              options: ['4', '5', '6', '7', '8'],
              correctIndex: 1,
              explanation: 'Два плюс три равно пять',
            ),
            Question(
              text: 'Какое число пропущено: 1, 2, _, 4, 5?',
              options: ['6', '3', '7', '8', '0'],
              correctIndex: 1,
              explanation: 'Пропущено число 3',
            ),
            Question(
              text: 'Сколько пальцев на одной руке?',
              options: ['3', '4', '5', '6', '10'],
              correctIndex: 2,
              explanation: 'На одной руке 5 пальцев',
            ),
          ],
        ),
        Topic(
          name: 'Первые фигуры',
          imageAsset: '🔺',
          description: 'Знакомство с геометрическими фигурами',
          explanation: 'Фигуры бывают разной формы',
          questions: [
            Question(
              text: 'Какая фигура имеет три угла?',
              options: ['Квадрат', 'Круг', 'Треугольник', 'Прямоугольник', 'Овал'],
              correctIndex: 2,
              explanation: 'Треугольник имеет три угла',
            ),
            Question(
              text: 'Как называется эта фигура? ⬜',
              options: ['Круг', 'Треугольник', 'Квадрат', 'Звезда', 'Сердце'],
              correctIndex: 2,
              explanation: 'Это квадрат - у него четыре равные стороны',
            ),
            Question(
              text: 'Какая фигура не имеет углов?',
              options: ['Квадрат', 'Треугольник', 'Круг', 'Прямоугольник', 'Ромб'],
              correctIndex: 2,
              explanation: 'Круг не имеет углов',
            ),
            Question(
              text: 'Сколько сторон у квадрата?',
              options: ['2', '3', '4', '5', '6'],
              correctIndex: 2,
              explanation: 'У квадрата 4 равные стороны',
            ),
            Question(
              text: 'Какая фигура похожа на мяч?',
              options: ['Куб', 'Шар', 'Пирамида', 'Конус', 'Цилиндр'],
              correctIndex: 1,
              explanation: 'Мяч имеет форму шара',
            ),
          ],
        ),
      ],
    },
  ),
];

// Математика 2 класс
final List<Subject> mathematicsSubjects2 = [
  Subject(
    name: 'Математика',
    topicsByGrade: {
      2: [
        Topic(
          name: 'Сложение и вычитание',
          imageAsset: '➕',
          description: 'Учимся решать примеры',
          explanation: 'Сложение увеличивает число, вычитание уменьшает',
          questions: [
            Question(
              text: 'Реши: 15 - 7 = ?',
              options: ['6', '7', '8', '9', '10'],
              correctIndex: 2,
              explanation: '15 - 7 = 8',
            ),
            Question(
              text: 'Сколько будет 9 + 6?',
              options: ['14', '15', '16', '13', '17'],
              correctIndex: 1,
              explanation: '9 + 6 = 15',
            ),
            Question(
              text: 'В классе 10 девочек и 8 мальчиков. Сколько всего детей?',
              options: ['16', '17', '18', '19', '20'],
              correctIndex: 2,
              explanation: '10 + 8 = 18 детей',
            ),
            Question(
              text: 'У Коли было 12 конфет. Он съел 4. Сколько осталось?',
              options: ['6', '7', '8', '9', '10'],
              correctIndex: 2,
              explanation: '12 - 4 = 8 конфет',
            ),
            Question(
              text: 'Найди сумму чисел 7 и 8',
              options: ['13', '14', '15', '16', '17'],
              correctIndex: 2,
              explanation: '7 + 8 = 15',
            ),
          ],
        ),
        Topic(
          name: 'Умножение чисел',
          imageAsset: '✖️',
          description: 'Изучаем таблицу умножения',
          explanation: 'Умножение - это быстрое сложение одинаковых чисел',
          questions: [
            Question(
              text: 'Сколько будет 3 × 4?',
              options: ['7', '12', '10', '8', '9'],
              correctIndex: 1,
              explanation: '3 × 4 = 12',
            ),
            Question(
              text: 'Реши: 5 × 2 = ?',
              options: ['7', '8', '10', '12', '15'],
              correctIndex: 2,
              explanation: '5 × 2 = 10',
            ),
            Question(
              text: 'У каждой кошки 4 лапы. Сколько лап у 3 кошек?',
              options: ['7', '10', '12', '14', '16'],
              correctIndex: 2,
              explanation: '3 × 4 = 12 лап',
            ),
            Question(
              text: 'Сколько будет 6 × 3?',
              options: ['15', '16', '17', '18', '19'],
              correctIndex: 3,
              explanation: '6 × 3 = 18',
            ),
            Question(
              text: 'В одной коробке 6 карандашей. Сколько в 4 коробках?',
              options: ['20', '22', '24', '26', '28'],
              correctIndex: 2,
              explanation: '6 × 4 = 24 карандаша',
            ),
          ],
        ),
      ],
    },
  ),
];

// Математика 3 класс
final List<Subject> mathematicsSubjects3 = [
  Subject(
    name: 'Математика',
    topicsByGrade: {
      3: [
        Topic(
          name: 'Деление чисел',
          imageAsset: '➗',
          description: 'Учимся делить числа',
          explanation: 'Деление - это обратное действие умножению',
          questions: [
            Question(
              text: 'Сколько будет 24 ÷ 6?',
              options: ['3', '4', '5', '6', '7'],
              correctIndex: 1,
              explanation: '24 ÷ 6 = 4',
            ),
            Question(
              text: 'Реши: 18 ÷ 3 = ?',
              options: ['5', '6', '7', '8', '9'],
              correctIndex: 1,
              explanation: '18 ÷ 3 = 6',
            ),
            Question(
              text: '18 конфет раздали 6 детям поровну. Сколько конфет получил каждый?',
              options: ['2', '3', '4', '5', '6'],
              correctIndex: 1,
              explanation: '18 ÷ 6 = 3 конфеты',
            ),
            Question(
              text: 'Сколько будет 35 ÷ 5?',
              options: ['5', '6', '7', '8', '9'],
              correctIndex: 2,
              explanation: '35 ÷ 5 = 7',
            ),
            Question(
              text: '20 яблок разложили в 4 корзины поровну. Сколько в каждой?',
              options: ['3', '4', '5', '6', '7'],
              correctIndex: 2,
              explanation: '20 ÷ 4 = 5 яблок',
            ),
          ],
        ),
        Topic(
          name: 'Текстовые задачи',
          imageAsset: '📝',
          description: 'Решаем задачи из жизни',
          explanation: 'Внимательно читай условие задачи',
          questions: [
            Question(
              text: 'У Маши 15 рублей, а у Пети на 7 рублей больше. Сколько рублей у Пети?',
              options: ['20', '21', '22', '23', '24'],
              correctIndex: 2,
              explanation: '15 + 7 = 22 рубля',
            ),
            Question(
              text: 'В коробке 20 карандашей. Из них 6 красных, остальные синие. Сколько синих карандашей?',
              options: ['12', '13', '14', '15', '16'],
              correctIndex: 2,
              explanation: '20 - 6 = 14 синих карандашей',
            ),
            Question(
              text: 'В саду собрали 25 кг яблок и 18 кг груш. На сколько кг яблок собрали больше?',
              options: ['5', '6', '7', '8', '9'],
              correctIndex: 2,
              explanation: '25 - 18 = 7 кг',
            ),
            Question(
              text: 'Блокнот стоит 30 рублей, а ручка - 15 рублей. Сколько стоит вся покупка?',
              options: ['40', '45', '50', '55', '60'],
              correctIndex: 1,
              explanation: '30 + 15 = 45 рублей',
            ),
            Question(
              text: 'В автобусе ехало 28 человек. На остановке вышли 9. Сколько осталось?',
              options: ['17', '18', '19', '20', '21'],
              correctIndex: 2,
              explanation: '28 - 9 = 19 человек',
            ),
          ],
        ),
      ],
    },
  ),
];

// Математика 4 класс
final List<Subject> mathematicsSubjects4 = [
  Subject(
    name: 'Математика',
    topicsByGrade: {
      4: [
        Topic(
          name: 'Обыкновенные дроби',
          imageAsset: '½',
          description: 'Знакомство с дробями',
          explanation: 'Дробь показывает часть целого',
          questions: [
            Question(
              text: 'Как записать "одна вторая"?',
              options: ['1/4', '1/2', '1/3', '2/1', '3/4'],
              correctIndex: 1,
              explanation: 'Одна вторая записывается как 1/2',
            ),
            Question(
              text: 'Что больше: 1/2 или 1/4?',
              options: ['1/4', '1/2', 'они равны', 'нельзя сравнить', '2/4'],
              correctIndex: 1,
              explanation: '1/2 больше чем 1/4',
            ),
            Question(
              text: 'Как называется число над чертой дроби?',
              options: ['Знаменатель', 'Числитель', 'Делитель', 'Частное', 'Разность'],
              correctIndex: 1,
              explanation: 'Число над чертой - числитель, под чертой - знаменатель',
            ),
            Question(
              text: 'Какой дробью записывается половина пиццы?',
              options: ['1/3', '1/4', '1/2', '2/3', '3/4'],
              correctIndex: 2,
              explanation: 'Половина - это 1/2',
            ),
            Question(
              text: 'Чему равна дробь 2/4?',
              options: ['1/8', '1/4', '1/3', '1/2', '2/3'],
              correctIndex: 3,
              explanation: '2/4 = 1/2',
            ),
          ],
        ),
        Topic(
          name: 'Измерение фигур',
          imageAsset: '📐',
          description: 'Находим периметр и площадь',
          explanation: 'Периметр - сумма длин всех сторон, площадь - размер поверхности',
          questions: [
            Question(
              text: 'Как найти периметр прямоугольника со сторонами 5 см и 3 см?',
              options: ['5+3', '5×3', '2×5+3', '2×(5+3)', '5×3×2'],
              correctIndex: 3,
              explanation: 'Периметр = 2 × (длина + ширина) = 2 × (5 + 3)',
            ),
            Question(
              text: 'Чему равна площадь квадрата со стороной 4 см?',
              options: ['8 см²', '12 см²', '16 см²', '20 см²', '24 см²'],
              correctIndex: 2,
              explanation: 'Площадь квадрата = сторона × сторона = 4 × 4 = 16 см²',
            ),
            Question(
              text: 'Периметр квадрата 20 см. Чему равна его сторона?',
              options: ['4 см', '5 см', '6 см', '8 см', '10 см'],
              correctIndex: 1,
              explanation: 'Сторона = периметр ÷ 4 = 20 ÷ 4 = 5 см',
            ),
            Question(
              text: 'Как найти площадь прямоугольника?',
              options: ['сложить все стороны', 'умножить длину на ширину', 'сложить длину и ширину', 'умножить на 2', 'разделить на 4'],
              correctIndex: 1,
              explanation: 'Площадь прямоугольника = длина × ширина',
            ),
            Question(
              text: 'Периметр треугольника со сторонами 3 см, 4 см и 5 см равен:',
              options: ['10 см', '11 см', '12 см', '13 см', '14 см'],
              correctIndex: 2,
              explanation: '3 + 4 + 5 = 12 см',
            ),
          ],
        ),
      ],
    },
  ),
];

final List<Subject> mathematicsSubjects5 = [];
final List<Subject> mathematicsSubjects6 = [];
final List<Subject> mathematicsSubjects7 = [];
final List<Subject> mathematicsSubjects8 = [];
final List<Subject> mathematicsSubjects9 = [];
final List<Subject> mathematicsSubjects10 = [];
final List<Subject> mathematicsSubjects11 = [];