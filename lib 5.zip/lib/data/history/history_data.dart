// history_data.dart
import '../../models/subject.dart';
import '../../models/topic.dart';
import '../../models/question.dart';
import 'history_localization.dart';

class HistoryData {
  static List<Subject> getHistorySubjectsByGrade(int grade, String languageCode) {
    switch (grade) {
      case 5: return [_createHistorySubject5(languageCode)];
      case 6: return [_createHistorySubject6(languageCode)];
      case 7: return [_createHistorySubject7(languageCode)];
      case 8: return [_createHistorySubject8(languageCode)];
      case 9: return [_createHistorySubject9(languageCode)];
      case 10: return [_createHistorySubject10(languageCode)];
      case 11: return [_createHistorySubject11(languageCode)];
      default: return [];
    }
  }

  // === 5 КЛАСС ===
  static Subject _createHistorySubject5(String languageCode) {
    return Subject(
      name: HistoryLocalization.getSubjectName(languageCode),
      topicsByGrade: {
        5: [
          _createIntroductionTopic(languageCode),
          _createPrimitiveSocietyTopic(languageCode),
          _createPrimitiveHuntersTopic(languageCode),
          _createPrimitiveBeliefsTopic(languageCode),
          _createAgricultureTopic(languageCode),
          _createAncientEgyptTopic(languageCode),
          _createEgyptianSocietyTopic(languageCode),
          _createEgyptianStateTopic(languageCode),
          _createEgyptianReligionTopic(languageCode),
          _createEgyptianScienceTopic(languageCode),
          _createMesopotamiaTopic(languageCode),
          _createBabylonTopic(languageCode),
          _createPhoeniciaTopic(languageCode),
          _createPalestineTopic(languageCode),
          _createAssyriaTopic(languageCode),
          _createPersiaTopic(languageCode),
          _createAncientIndiaTopic(languageCode),
          _createAncientChinaTopic(languageCode),
          _createGreekCivilizationTopic(languageCode),
          _createGreekBeliefsTopic(languageCode),
          _createHomericGreeceTopic(languageCode),
          _createGreekPolisTopic(languageCode),
          _createGrecoPersianWarsTopic(languageCode),
          _createAthensTopic(languageCode),
          _createMacedonianConquestTopic(languageCode),
          _createEarlyRomeTopic(languageCode),
          _createRomanRepublicTopic(languageCode),
          _createRomanConquestTopic(languageCode),
          _createPunicWarsTopic(languageCode),
          _createRepublicCrisisTopic(languageCode),
          _createCaesarTopic(languageCode),
          _createRomanEmpireTopic(languageCode),
          _createChristianityTopic(languageCode),
          _createFallOfRomeTopic(languageCode),
          _createAncientWorldLegacyTopic(languageCode),
        ],
      },
    );
  }

  // Тема: Введение
  static Topic _createIntroductionTopic(String languageCode) {
    return Topic(
      id: 'history_5_introduction',
      name: HistoryLocalization.getIntroductionName(languageCode),
      imageAsset: '📜',
      description: HistoryLocalization.getIntroductionDescription(languageCode),
      explanation: HistoryLocalization.getIntroductionExplanation(languageCode),
      questions: _createIntroductionQuestions(languageCode),
    );
  }

  static List<Question> _createIntroductionQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 0),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 1),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 2),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 3),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 4),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 5),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 6),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 7),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 8),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 8),
        correctIndex: 0,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getIntroductionQuestion(languageCode, 9),
        options: HistoryLocalization.getIntroductionOptions(languageCode, 9),
        correctIndex: 0,
        explanation: HistoryLocalization.getIntroductionAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Первобытное общество
  static Topic _createPrimitiveSocietyTopic(String languageCode) {
    return Topic(
      id: 'history_5_primitive_society',
      name: HistoryLocalization.getPrimitiveSocietyName(languageCode),
      imageAsset: '🦍',
      description: HistoryLocalization.getPrimitiveSocietyDescription(languageCode),
      explanation: HistoryLocalization.getPrimitiveSocietyExplanation(languageCode),
      questions: _createPrimitiveSocietyQuestions(languageCode),
    );
  }

  static List<Question> _createPrimitiveSocietyQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 0),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 1),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 2),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 3),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 4),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 5),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 5),
        correctIndex: 3,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 6),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 7),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 8),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 8),
        correctIndex: 0,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveSocietyQuestion(languageCode, 9),
        options: HistoryLocalization.getPrimitiveSocietyOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveSocietyAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Первобытные охотники и собиратели
  static Topic _createPrimitiveHuntersTopic(String languageCode) {
    return Topic(
      id: 'history_5_primitive_hunters',
      name: HistoryLocalization.getPrimitiveHuntersName(languageCode),
      imageAsset: '🏹',
      description: HistoryLocalization.getPrimitiveHuntersDescription(languageCode),
      explanation: HistoryLocalization.getPrimitiveHuntersExplanation(languageCode),
      questions: _createPrimitiveHuntersQuestions(languageCode),
    );
  }

  static List<Question> _createPrimitiveHuntersQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 0),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 1),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 2),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 3),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 3),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 4),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 5),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 6),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 7),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 8),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveHuntersQuestion(languageCode, 9),
        options: HistoryLocalization.getPrimitiveHuntersOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveHuntersAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Верования и искусство первобытных людей
  static Topic _createPrimitiveBeliefsTopic(String languageCode) {
    return Topic(
      id: 'history_5_primitive_beliefs',
      name: HistoryLocalization.getPrimitiveBeliefsName(languageCode),
      imageAsset: '🎨',
      description: HistoryLocalization.getPrimitiveBeliefsDescription(languageCode),
      explanation: HistoryLocalization.getPrimitiveBeliefsExplanation(languageCode),
      questions: _createPrimitiveBeliefsQuestions(languageCode),
    );
  }

  static List<Question> _createPrimitiveBeliefsQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 0),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 1),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 2),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 3),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 4),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 4),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 5),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 6),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 6),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 7),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 8),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 8),
        correctIndex: 2,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPrimitiveBeliefsQuestion(languageCode, 9),
        options: HistoryLocalization.getPrimitiveBeliefsOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPrimitiveBeliefsAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Возникновение земледелия, скотоводства и ремесла
  static Topic _createAgricultureTopic(String languageCode) {
    return Topic(
      id: 'history_5_agriculture',
      name: HistoryLocalization.getAgricultureName(languageCode),
      imageAsset: '🌾',
      description: HistoryLocalization.getAgricultureDescription(languageCode),
      explanation: HistoryLocalization.getAgricultureExplanation(languageCode),
      questions: _createAgricultureQuestions(languageCode),
    );
  }

  static List<Question> _createAgricultureQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 0),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 1),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 2),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 3),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 4),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 4),
        correctIndex: 2,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 5),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 6),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 7),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 8),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 8),
        correctIndex: 2,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAgricultureQuestion(languageCode, 9),
        options: HistoryLocalization.getAgricultureOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAgricultureAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древний Египет
  static Topic _createAncientEgyptTopic(String languageCode) {
    return Topic(
      id: 'history_5_ancient_egypt',
      name: HistoryLocalization.getAncientEgyptName(languageCode),
      imageAsset: '🏺',
      description: HistoryLocalization.getAncientEgyptDescription(languageCode),
      explanation: HistoryLocalization.getAncientEgyptExplanation(languageCode),
      questions: _createAncientEgyptQuestions(languageCode),
    );
  }

  static List<Question> _createAncientEgyptQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 0),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 1),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 1),
        correctIndex: 3,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 2),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 3),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 4),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 5),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 6),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 7),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 8),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientEgyptQuestion(languageCode, 9),
        options: HistoryLocalization.getAncientEgyptOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientEgyptAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Общество Древнего Египта
  static Topic _createEgyptianSocietyTopic(String languageCode) {
    return Topic(
      id: 'history_5_egyptian_society',
      name: HistoryLocalization.getEgyptianSocietyName(languageCode),
      imageAsset: '👑',
      description: HistoryLocalization.getEgyptianSocietyDescription(languageCode),
      explanation: HistoryLocalization.getEgyptianSocietyExplanation(languageCode),
      questions: _createEgyptianSocietyQuestions(languageCode),
    );
  }

  static List<Question> _createEgyptianSocietyQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 0),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 1),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 2),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 3),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 4),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 5),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 6),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 7),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 8),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianSocietyQuestion(languageCode, 9),
        options: HistoryLocalization.getEgyptianSocietyOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianSocietyAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Расцвет Древнеегипетского государства
  static Topic _createEgyptianStateTopic(String languageCode) {
    return Topic(
      id: 'history_5_egyptian_state',
      name: HistoryLocalization.getEgyptianStateName(languageCode),
      imageAsset: '⚔️',
      description: HistoryLocalization.getEgyptianStateDescription(languageCode),
      explanation: HistoryLocalization.getEgyptianStateExplanation(languageCode),
      questions: _createEgyptianStateQuestions(languageCode),
    );
  }

  static List<Question> _createEgyptianStateQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 0),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 1),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 2),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 3),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 4),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 5),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 6),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 6),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 7),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 8),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianStateQuestion(languageCode, 9),
        options: HistoryLocalization.getEgyptianStateOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianStateAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Религия Древнего Египта
  static Topic _createEgyptianReligionTopic(String languageCode) {
    return Topic(
      id: 'history_5_egyptian_religion',
      name: HistoryLocalization.getEgyptianReligionName(languageCode),
      imageAsset: '☀️',
      description: HistoryLocalization.getEgyptianReligionDescription(languageCode),
      explanation: HistoryLocalization.getEgyptianReligionExplanation(languageCode),
      questions: _createEgyptianReligionQuestions(languageCode),
    );
  }

  static List<Question> _createEgyptianReligionQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 0),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 1),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 2),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 3),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 4),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 5),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 6),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 7),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 8),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianReligionQuestion(languageCode, 9),
        options: HistoryLocalization.getEgyptianReligionOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianReligionAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Наука и искусство Древнего Египта
  static Topic _createEgyptianScienceTopic(String languageCode) {
    return Topic(
      id: 'history_5_egyptian_science',
      name: HistoryLocalization.getEgyptianScienceName(languageCode),
      imageAsset: '📐',
      description: HistoryLocalization.getEgyptianScienceDescription(languageCode),
      explanation: HistoryLocalization.getEgyptianScienceExplanation(languageCode),
      questions: _createEgyptianScienceQuestions(languageCode),
    );
  }

  static List<Question> _createEgyptianScienceQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 0),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 1),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 2),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 3),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 4),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 5),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 6),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 7),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 7),
        correctIndex: 2,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 8),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEgyptianScienceQuestion(languageCode, 9),
        options: HistoryLocalization.getEgyptianScienceOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getEgyptianScienceAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древнее Междуречье
  static Topic _createMesopotamiaTopic(String languageCode) {
    return Topic(
      id: 'history_5_mesopotamia',
      name: HistoryLocalization.getMesopotamiaName(languageCode),
      imageAsset: '🏛️',
      description: HistoryLocalization.getMesopotamiaDescription(languageCode),
      explanation: HistoryLocalization.getMesopotamiaExplanation(languageCode),
      questions: _createMesopotamiaQuestions(languageCode),
    );
  }

  static List<Question> _createMesopotamiaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 0),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 1),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 2),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 2),
        correctIndex: 0,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 3),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 4),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 4),
        correctIndex: 2,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 5),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 6),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 7),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 8),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMesopotamiaQuestion(languageCode, 9),
        options: HistoryLocalization.getMesopotamiaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getMesopotamiaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Вавилонское царство
  static Topic _createBabylonTopic(String languageCode) {
    return Topic(
      id: 'history_5_babylon',
      name: HistoryLocalization.getBabylonName(languageCode),
      imageAsset: '⚖️',
      description: HistoryLocalization.getBabylonDescription(languageCode),
      explanation: HistoryLocalization.getBabylonExplanation(languageCode),
      questions: _createBabylonQuestions(languageCode),
    );
  }

  static List<Question> _createBabylonQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 0),
        options: HistoryLocalization.getBabylonOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 1),
        options: HistoryLocalization.getBabylonOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 2),
        options: HistoryLocalization.getBabylonOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 3),
        options: HistoryLocalization.getBabylonOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 4),
        options: HistoryLocalization.getBabylonOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 5),
        options: HistoryLocalization.getBabylonOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 6),
        options: HistoryLocalization.getBabylonOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 7),
        options: HistoryLocalization.getBabylonOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 8),
        options: HistoryLocalization.getBabylonOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getBabylonQuestion(languageCode, 9),
        options: HistoryLocalization.getBabylonOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getBabylonAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Финикия
  static Topic _createPhoeniciaTopic(String languageCode) {
    return Topic(
      id: 'history_5_phoenicia',
      name: HistoryLocalization.getPhoeniciaName(languageCode),
      imageAsset: '🚢',
      description: HistoryLocalization.getPhoeniciaDescription(languageCode),
      explanation: HistoryLocalization.getPhoeniciaExplanation(languageCode),
      questions: _createPhoeniciaQuestions(languageCode),
    );
  }

  static List<Question> _createPhoeniciaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 0),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 1),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 2),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 3),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 4),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 5),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 6),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 7),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 8),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 8),
        correctIndex: 2,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPhoeniciaQuestion(languageCode, 9),
        options: HistoryLocalization.getPhoeniciaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPhoeniciaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древняя Палестина
  static Topic _createPalestineTopic(String languageCode) {
    return Topic(
      id: 'history_5_palestine',
      name: HistoryLocalization.getPalestineName(languageCode),
      imageAsset: '✡️',
      description: HistoryLocalization.getPalestineDescription(languageCode),
      explanation: HistoryLocalization.getPalestineExplanation(languageCode),
      questions: _createPalestineQuestions(languageCode),
    );
  }

  static List<Question> _createPalestineQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 0),
        options: HistoryLocalization.getPalestineOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 1),
        options: HistoryLocalization.getPalestineOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 2),
        options: HistoryLocalization.getPalestineOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 3),
        options: HistoryLocalization.getPalestineOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 4),
        options: HistoryLocalization.getPalestineOptions(languageCode, 4),
        correctIndex: 0,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 5),
        options: HistoryLocalization.getPalestineOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 6),
        options: HistoryLocalization.getPalestineOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 7),
        options: HistoryLocalization.getPalestineOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 8),
        options: HistoryLocalization.getPalestineOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPalestineQuestion(languageCode, 9),
        options: HistoryLocalization.getPalestineOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPalestineAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Ассирийская держава
  static Topic _createAssyriaTopic(String languageCode) {
    return Topic(
      id: 'history_5_assyria',
      name: HistoryLocalization.getAssyriaName(languageCode),
      imageAsset: '🛡️',
      description: HistoryLocalization.getAssyriaDescription(languageCode),
      explanation: HistoryLocalization.getAssyriaExplanation(languageCode),
      questions: _createAssyriaQuestions(languageCode),
    );
  }

  static List<Question> _createAssyriaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 0),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 1),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 2),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 3),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 4),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 5),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 5),
        correctIndex: 0,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 6),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 6),
        correctIndex: 0,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 7),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 8),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAssyriaQuestion(languageCode, 9),
        options: HistoryLocalization.getAssyriaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAssyriaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Персидское царство
  static Topic _createPersiaTopic(String languageCode) {
    return Topic(
      id: 'history_5_persia',
      name: HistoryLocalization.getPersiaName(languageCode),
      imageAsset: '👑',
      description: HistoryLocalization.getPersiaDescription(languageCode),
      explanation: HistoryLocalization.getPersiaExplanation(languageCode),
      questions: _createPersiaQuestions(languageCode),
    );
  }

  static List<Question> _createPersiaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 0),
        options: HistoryLocalization.getPersiaOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 1),
        options: HistoryLocalization.getPersiaOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 2),
        options: HistoryLocalization.getPersiaOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 3),
        options: HistoryLocalization.getPersiaOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 4),
        options: HistoryLocalization.getPersiaOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 5),
        options: HistoryLocalization.getPersiaOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 6),
        options: HistoryLocalization.getPersiaOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 7),
        options: HistoryLocalization.getPersiaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 8),
        options: HistoryLocalization.getPersiaOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPersiaQuestion(languageCode, 9),
        options: HistoryLocalization.getPersiaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getPersiaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древняя Индия
  static Topic _createAncientIndiaTopic(String languageCode) {
    return Topic(
      id: 'history_5_ancient_india',
      name: HistoryLocalization.getAncientIndiaName(languageCode),
      imageAsset: '🐘',
      description: HistoryLocalization.getAncientIndiaDescription(languageCode),
      explanation: HistoryLocalization.getAncientIndiaExplanation(languageCode),
      questions: _createAncientIndiaQuestions(languageCode),
    );
  }

  static List<Question> _createAncientIndiaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 0),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 0),
        correctIndex: 0,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 1),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 2),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 3),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 3),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 4),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 5),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 6),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 7),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 8),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientIndiaQuestion(languageCode, 9),
        options: HistoryLocalization.getAncientIndiaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientIndiaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древний Китай
  static Topic _createAncientChinaTopic(String languageCode) {
    return Topic(
      id: 'history_5_ancient_china',
      name: HistoryLocalization.getAncientChinaName(languageCode),
      imageAsset: '🐉',
      description: HistoryLocalization.getAncientChinaDescription(languageCode),
      explanation: HistoryLocalization.getAncientChinaExplanation(languageCode),
      questions: _createAncientChinaQuestions(languageCode),
    );
  }

  static List<Question> _createAncientChinaQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 0),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 1),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 2),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 3),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 4),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 4),
        correctIndex: 3,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 5),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 6),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 7),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 8),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientChinaQuestion(languageCode, 9),
        options: HistoryLocalization.getAncientChinaOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientChinaAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Начало греческой цивилизации
  static Topic _createGreekCivilizationTopic(String languageCode) {
    return Topic(
      id: 'history_5_greek_civilization',
      name: HistoryLocalization.getGreekCivilizationName(languageCode),
      imageAsset: '🏺',
      description: HistoryLocalization.getGreekCivilizationDescription(languageCode),
      explanation: HistoryLocalization.getGreekCivilizationExplanation(languageCode),
      questions: _createGreekCivilizationQuestions(languageCode),
    );
  }

  static List<Question> _createGreekCivilizationQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 0),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 1),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 2),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 3),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 4),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 5),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 6),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 7),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 8),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekCivilizationQuestion(languageCode, 9),
        options: HistoryLocalization.getGreekCivilizationOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekCivilizationAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Верования древних греков
  static Topic _createGreekBeliefsTopic(String languageCode) {
    return Topic(
      id: 'history_5_greek_beliefs',
      name: HistoryLocalization.getGreekBeliefsName(languageCode),
      imageAsset: '⚡',
      description: HistoryLocalization.getGreekBeliefsDescription(languageCode),
      explanation: HistoryLocalization.getGreekBeliefsExplanation(languageCode),
      questions: _createGreekBeliefsQuestions(languageCode),
    );
  }

  static List<Question> _createGreekBeliefsQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 0),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 1),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 2),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 3),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 4),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 5),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 6),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 7),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 8),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekBeliefsQuestion(languageCode, 9),
        options: HistoryLocalization.getGreekBeliefsOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekBeliefsAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Гомеровская Греция
  static Topic _createHomericGreeceTopic(String languageCode) {
    return Topic(
      id: 'history_5_homeric_greece',
      name: HistoryLocalization.getHomericGreeceName(languageCode),
      imageAsset: '📖',
      description: HistoryLocalization.getHomericGreeceDescription(languageCode),
      explanation: HistoryLocalization.getHomericGreeceExplanation(languageCode),
      questions: _createHomericGreeceQuestions(languageCode),
    );
  }

  static List<Question> _createHomericGreeceQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 0),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 1),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 2),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 3),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 4),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 5),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 6),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 7),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 8),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getHomericGreeceQuestion(languageCode, 9),
        options: HistoryLocalization.getHomericGreeceOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getHomericGreeceAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Древнегреческие полисы
  static Topic _createGreekPolisTopic(String languageCode) {
    return Topic(
      id: 'history_5_greek_polis',
      name: HistoryLocalization.getGreekPolisName(languageCode),
      imageAsset: '🏛️',
      description: HistoryLocalization.getGreekPolisDescription(languageCode),
      explanation: HistoryLocalization.getGreekPolisExplanation(languageCode),
      questions: _createGreekPolisQuestions(languageCode),
    );
  }

  static List<Question> _createGreekPolisQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 0),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 1),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 2),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 3),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 4),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 5),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 6),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 7),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 8),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGreekPolisQuestion(languageCode, 9),
        options: HistoryLocalization.getGreekPolisOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getGreekPolisAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Греко-персидские войны
  static Topic _createGrecoPersianWarsTopic(String languageCode) {
    return Topic(
      id: 'history_5_greco_persian_wars',
      name: HistoryLocalization.getGrecoPersianWarsName(languageCode),
      imageAsset: '⚔️',
      description: HistoryLocalization.getGrecoPersianWarsDescription(languageCode),
      explanation: HistoryLocalization.getGrecoPersianWarsExplanation(languageCode),
      questions: _createGrecoPersianWarsQuestions(languageCode),
    );
  }

  static List<Question> _createGrecoPersianWarsQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 0),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 1),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 2),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 2),
        correctIndex: 3,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 3),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 4),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 5),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 6),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 7),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 8),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 8),
        correctIndex: 3,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getGrecoPersianWarsQuestion(languageCode, 9),
        options: HistoryLocalization.getGrecoPersianWarsOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getGrecoPersianWarsAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Расцвет Афин
  static Topic _createAthensTopic(String languageCode) {
    return Topic(
      id: 'history_5_athens',
      name: HistoryLocalization.getAthensName(languageCode),
      imageAsset: '🏺',
      description: HistoryLocalization.getAthensDescription(languageCode),
      explanation: HistoryLocalization.getAthensExplanation(languageCode),
      questions: _createAthensQuestions(languageCode),
    );
  }

  static List<Question> _createAthensQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 0),
        options: HistoryLocalization.getAthensOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 1),
        options: HistoryLocalization.getAthensOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 2),
        options: HistoryLocalization.getAthensOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 3),
        options: HistoryLocalization.getAthensOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 4),
        options: HistoryLocalization.getAthensOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 5),
        options: HistoryLocalization.getAthensOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 6),
        options: HistoryLocalization.getAthensOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 7),
        options: HistoryLocalization.getAthensOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 8),
        options: HistoryLocalization.getAthensOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAthensQuestion(languageCode, 9),
        options: HistoryLocalization.getAthensOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getAthensAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Македонское завоевание
  static Topic _createMacedonianConquestTopic(String languageCode) {
    return Topic(
      id: 'history_5_macedonian_conquest',
      name: HistoryLocalization.getMacedonianConquestName(languageCode),
      imageAsset: '👑',
      description: HistoryLocalization.getMacedonianConquestDescription(languageCode),
      explanation: HistoryLocalization.getMacedonianConquestExplanation(languageCode),
      questions: _createMacedonianConquestQuestions(languageCode),
    );
  }

  static List<Question> _createMacedonianConquestQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 0),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 1),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 2),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 3),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 4),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 5),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 6),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 7),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 8),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 8),
        correctIndex: 0,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getMacedonianConquestQuestion(languageCode, 9),
        options: HistoryLocalization.getMacedonianConquestOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getMacedonianConquestAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Ранний Рим
  static Topic _createEarlyRomeTopic(String languageCode) {
    return Topic(
      id: 'history_5_early_rome',
      name: HistoryLocalization.getEarlyRomeName(languageCode),
      imageAsset: '🏛️',
      description: HistoryLocalization.getEarlyRomeDescription(languageCode),
      explanation: HistoryLocalization.getEarlyRomeExplanation(languageCode),
      questions: _createEarlyRomeQuestions(languageCode),
    );
  }

  static List<Question> _createEarlyRomeQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 0),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 1),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 2),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 3),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 4),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 5),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 6),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 7),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 8),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getEarlyRomeQuestion(languageCode, 9),
        options: HistoryLocalization.getEarlyRomeOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getEarlyRomeAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Римская республика
  static Topic _createRomanRepublicTopic(String languageCode) {
    return Topic(
      id: 'history_5_roman_republic',
      name: HistoryLocalization.getRomanRepublicName(languageCode),
      imageAsset: '⚖️',
      description: HistoryLocalization.getRomanRepublicDescription(languageCode),
      explanation: HistoryLocalization.getRomanRepublicExplanation(languageCode),
      questions: _createRomanRepublicQuestions(languageCode),
    );
  }

  static List<Question> _createRomanRepublicQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 0),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 1),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 2),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 3),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 4),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 5),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 6),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 7),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 8),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanRepublicQuestion(languageCode, 9),
        options: HistoryLocalization.getRomanRepublicOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanRepublicAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Завоевание Римом Италии
  static Topic _createRomanConquestTopic(String languageCode) {
    return Topic(
      id: 'history_5_roman_conquest',
      name: HistoryLocalization.getRomanConquestName(languageCode),
      imageAsset: '⚔️',
      description: HistoryLocalization.getRomanConquestDescription(languageCode),
      explanation: HistoryLocalization.getRomanConquestExplanation(languageCode),
      questions: _createRomanConquestQuestions(languageCode),
    );
  }

  static List<Question> _createRomanConquestQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 0),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 1),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 2),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 3),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 4),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 5),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 5),
        correctIndex: 0,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 6),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 7),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 7),
        correctIndex: 0,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 8),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanConquestQuestion(languageCode, 9),
        options: HistoryLocalization.getRomanConquestOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanConquestAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Пунические войны
  static Topic _createPunicWarsTopic(String languageCode) {
    return Topic(
      id: 'history_5_punic_wars',
      name: HistoryLocalization.getPunicWarsName(languageCode),
      imageAsset: '🚢',
      description: HistoryLocalization.getPunicWarsDescription(languageCode),
      explanation: HistoryLocalization.getPunicWarsExplanation(languageCode),
      questions: _createPunicWarsQuestions(languageCode),
    );
  }

  static List<Question> _createPunicWarsQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 0),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 1),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 2),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 3),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 4),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 5),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 5),
        correctIndex: 0,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 6),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 7),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 8),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 8),
        correctIndex: 0,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getPunicWarsQuestion(languageCode, 9),
        options: HistoryLocalization.getPunicWarsOptions(languageCode, 9),
        correctIndex: 2,
        explanation: HistoryLocalization.getPunicWarsAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Кризис Римской республики
  static Topic _createRepublicCrisisTopic(String languageCode) {
    return Topic(
      id: 'history_5_republic_crisis',
      name: HistoryLocalization.getRepublicCrisisName(languageCode),
      imageAsset: '⚔️',
      description: HistoryLocalization.getRepublicCrisisDescription(languageCode),
      explanation: HistoryLocalization.getRepublicCrisisExplanation(languageCode),
      questions: _createRepublicCrisisQuestions(languageCode),
    );
  }

  static List<Question> _createRepublicCrisisQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 0),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 1),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 2),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 3),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 3),
        correctIndex: 4,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 4),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 5),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 6),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 7),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 8),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRepublicCrisisQuestion(languageCode, 9),
        options: HistoryLocalization.getRepublicCrisisOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getRepublicCrisisAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Падение республики. Диктатура Цезаря
  static Topic _createCaesarTopic(String languageCode) {
    return Topic(
      id: 'history_5_caesar',
      name: HistoryLocalization.getCaesarName(languageCode),
      imageAsset: '👑',
      description: HistoryLocalization.getCaesarDescription(languageCode),
      explanation: HistoryLocalization.getCaesarExplanation(languageCode),
      questions: _createCaesarQuestions(languageCode),
    );
  }

  static List<Question> _createCaesarQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 0),
        options: HistoryLocalization.getCaesarOptions(languageCode, 0),
        correctIndex: 0,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 1),
        options: HistoryLocalization.getCaesarOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 2),
        options: HistoryLocalization.getCaesarOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 3),
        options: HistoryLocalization.getCaesarOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 4),
        options: HistoryLocalization.getCaesarOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 5),
        options: HistoryLocalization.getCaesarOptions(languageCode, 5),
        correctIndex: 0,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 6),
        options: HistoryLocalization.getCaesarOptions(languageCode, 6),
        correctIndex: 2,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 7),
        options: HistoryLocalization.getCaesarOptions(languageCode, 7),
        correctIndex: 0,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 8),
        options: HistoryLocalization.getCaesarOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getCaesarQuestion(languageCode, 9),
        options: HistoryLocalization.getCaesarOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getCaesarAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Римская империя
  static Topic _createRomanEmpireTopic(String languageCode) {
    return Topic(
      id: 'history_5_roman_empire',
      name: HistoryLocalization.getRomanEmpireName(languageCode),
      imageAsset: '🏛️',
      description: HistoryLocalization.getRomanEmpireDescription(languageCode),
      explanation: HistoryLocalization.getRomanEmpireExplanation(languageCode),
      questions: _createRomanEmpireQuestions(languageCode),
    );
  }

  static List<Question> _createRomanEmpireQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 0),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 1),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 2),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 3),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 4),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 5),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 6),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 7),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 8),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getRomanEmpireQuestion(languageCode, 9),
        options: HistoryLocalization.getRomanEmpireOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getRomanEmpireAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Возникновение христианства
  static Topic _createChristianityTopic(String languageCode) {
    return Topic(
      id: 'history_5_christianity',
      name: HistoryLocalization.getChristianityName(languageCode),
      imageAsset: '✝️',
      description: HistoryLocalization.getChristianityDescription(languageCode),
      explanation: HistoryLocalization.getChristianityExplanation(languageCode),
      questions: _createChristianityQuestions(languageCode),
    );
  }

  static List<Question> _createChristianityQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 0),
        options: HistoryLocalization.getChristianityOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 1),
        options: HistoryLocalization.getChristianityOptions(languageCode, 1),
        correctIndex: 1,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 2),
        options: HistoryLocalization.getChristianityOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 3),
        options: HistoryLocalization.getChristianityOptions(languageCode, 3),
        correctIndex: 2,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 4),
        options: HistoryLocalization.getChristianityOptions(languageCode, 4),
        correctIndex: 2,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 5),
        options: HistoryLocalization.getChristianityOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 6),
        options: HistoryLocalization.getChristianityOptions(languageCode, 6),
        correctIndex: 1,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 7),
        options: HistoryLocalization.getChristianityOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 8),
        options: HistoryLocalization.getChristianityOptions(languageCode, 8),
        correctIndex: 1,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getChristianityQuestion(languageCode, 9),
        options: HistoryLocalization.getChristianityOptions(languageCode, 9),
        correctIndex: 2,
        explanation: HistoryLocalization.getChristianityAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Кризис и падение Римской империи
  static Topic _createFallOfRomeTopic(String languageCode) {
    return Topic(
      id: 'history_5_fall_of_rome',
      name: HistoryLocalization.getFallOfRomeName(languageCode),
      imageAsset: '🏛️',
      description: HistoryLocalization.getFallOfRomeDescription(languageCode),
      explanation: HistoryLocalization.getFallOfRomeExplanation(languageCode),
      questions: _createFallOfRomeQuestions(languageCode),
    );
  }

  static List<Question> _createFallOfRomeQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 0),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 0),
        correctIndex: 1,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 1),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 2),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 2),
        correctIndex: 2,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 3),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 3),
        correctIndex: 2,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 4),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 4),
        correctIndex: 1,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 5),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 5),
        correctIndex: 1,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 6),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 6),
        correctIndex: 2,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 7),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 7),
        correctIndex: 1,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 8),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 8),
        correctIndex: 2,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getFallOfRomeQuestion(languageCode, 9),
        options: HistoryLocalization.getFallOfRomeOptions(languageCode, 9),
        correctIndex: 1,
        explanation: HistoryLocalization.getFallOfRomeAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }

  // Тема: Итоги истории Древнего мира
  static Topic _createAncientWorldLegacyTopic(String languageCode) {
    return Topic(
      id: 'history_5_ancient_world_legacy',
      name: HistoryLocalization.getAncientWorldLegacyName(languageCode),
      imageAsset: '📚',
      description: HistoryLocalization.getAncientWorldLegacyDescription(languageCode),
      explanation: HistoryLocalization.getAncientWorldLegacyExplanation(languageCode),
      questions: _createAncientWorldLegacyQuestions(languageCode),
    );
  }

  static List<Question> _createAncientWorldLegacyQuestions(String languageCode) {
    return [
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 0),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 0),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 1),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 1),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 2),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 2),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 3),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 3),
        correctIndex: 1,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 4),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 4),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 5),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 5),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 5),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 6),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 6),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 6),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 7),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 7),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 7),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 8),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 8),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 8),
        answerType: 'choice',
      ),
      Question(
        text: HistoryLocalization.getAncientWorldLegacyQuestion(languageCode, 9),
        options: HistoryLocalization.getAncientWorldLegacyOptions(languageCode, 9),
        correctIndex: 2,
        explanation: HistoryLocalization.getAncientWorldLegacyAnswerExplanation(languageCode, 9),
        answerType: 'choice',
      ),
    ];
  }
}