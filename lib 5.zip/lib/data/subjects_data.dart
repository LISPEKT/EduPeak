import 'package:flutter/material.dart';
import '../../models/subject.dart';
import '../localization.dart';

// Импорты для всех предметов
//import 'mathematics/mathematics_data.dart';
//import 'russian_language/russian_language_data.dart';
import 'algebra/algebra_data.dart';
//import 'physics/physics_data.dart';
import 'history/history_data.dart';
// Раскомментируйте по мере добавления предметов:
// import 'geometry/geometry_data.dart';
// import 'english_language/english_language_data.dart';
// import 'literature/literature_data.dart';
// import 'biology/biology_data.dart';
// import 'chemistry/chemistry_data.dart';
// import 'geography/geography_data.dart';
// import 'social_studies/social_studies_data.dart';
// import 'computer_science/computer_science_data.dart';
// import 'statistics_probability/statistics_probability_data.dart';

class SubjectsData {
  static Map<int, List<Subject>> getSubjectsByGrade(String languageCode) {
    return {
      1: [
        //...RussianLanguageData.getRussianSubjectsByGrade(1, languageCode),
        //...MathematicsData.getMathematicsSubjectsByGrade(1, languageCode),
      ],
      2: [
        //...RussianLanguageData.getRussianSubjectsByGrade(2, languageCode),
        //...MathematicsData.getMathematicsSubjectsByGrade(2, languageCode),
      ],
      3: [
        //...RussianLanguageData.getRussianSubjectsByGrade(3, languageCode),
        //...MathematicsData.getMathematicsSubjectsByGrade(3, languageCode),
      ],
      4: [
        //...RussianLanguageData.getRussianSubjectsByGrade(4, languageCode),
        //...MathematicsData.getMathematicsSubjectsByGrade(4, languageCode),
      ],
      5: [
        //...RussianLanguageData.getRussianSubjectsByGrade(5, languageCode),
        ...AlgebraData.getAlgebraSubjectsByGrade(5, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(5, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(5, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(5, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(5, languageCode),
        ...HistoryData.getHistorySubjectsByGrade(5, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(5, languageCode),
      ],
      6: [
        //...RussianLanguageData.getRussianSubjectsByGrade(6, languageCode),
        ...AlgebraData.getAlgebraSubjectsByGrade(6, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(6, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(6, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(6, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(6, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(6, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(6, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(6, languageCode),
      ],
      7: [
        //...RussianLanguageData.getRussianSubjectsByGrade(7, languageCode),
        //...AlgebraData.getAlgebraSubjectsByGrade(7, languageCode),
        //...PhysicsData.getPhysicsSubjectsByGrade(7, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(7, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(7, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(7, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(7, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(7, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(7, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(7, languageCode),
      ],
      8: [
        //...RussianLanguageData.getRussianSubjectsByGrade(8, languageCode),
        //...AlgebraData.getAlgebraSubjectsByGrade(8, languageCode),
        //...PhysicsData.getPhysicsSubjectsByGrade(8, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(8, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(8, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(8, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(8, languageCode),
        // ...ChemistryData.getChemistrySubjectsByGrade(8, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(8, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(8, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(8, languageCode),
      ],
      9: [
        //...RussianLanguageData.getRussianSubjectsByGrade(9, languageCode),
        //...AlgebraData.getAlgebraSubjectsByGrade(9, languageCode),
        //...PhysicsData.getPhysicsSubjectsByGrade(9, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(9, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(9, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(9, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(9, languageCode),
        // ...ChemistryData.getChemistrySubjectsByGrade(9, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(9, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(9, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(9, languageCode),
      ],
      10: [
        //...RussianLanguageData.getRussianSubjectsByGrade(10, languageCode),
        //...AlgebraData.getAlgebraSubjectsByGrade(10, languageCode),
        //...PhysicsData.getPhysicsSubjectsByGrade(10, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(10, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(10, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(10, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(10, languageCode),
        // ...ChemistryData.getChemistrySubjectsByGrade(10, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(10, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(10, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(10, languageCode),
        // ...ComputerScienceData.getComputerScienceSubjectsByGrade(10, languageCode),
        // ...StatisticsProbabilityData.getStatisticsProbabilitySubjectsByGrade(10, languageCode),
      ],
      11: [
        //...RussianLanguageData.getRussianSubjectsByGrade(11, languageCode),
        //...AlgebraData.getAlgebraSubjectsByGrade(11, languageCode),
        //...PhysicsData.getPhysicsSubjectsByGrade(11, languageCode),
        // ...GeometryData.getGeometrySubjectsByGrade(11, languageCode),
        // ...EnglishLanguageData.getEnglishSubjectsByGrade(11, languageCode),
        // ...LiteratureData.getLiteratureSubjectsByGrade(11, languageCode),
        // ...BiologyData.getBiologySubjectsByGrade(11, languageCode),
        // ...ChemistryData.getChemistrySubjectsByGrade(11, languageCode),
        //...HistoryData.getHistorySubjectsByGrade(11, languageCode),
        // ...GeographyData.getGeographySubjectsByGrade(11, languageCode),
        // ...SocialStudiesData.getSocialStudiesSubjectsByGrade(11, languageCode),
        // ...ComputerScienceData.getComputerScienceSubjectsByGrade(11, languageCode),
        // ...StatisticsProbabilityData.getStatisticsProbabilitySubjectsByGrade(11, languageCode),
      ],
    };
  }

  // Вспомогательные методы
  static List<String> getAvailableSubjects(String languageCode) {
    final allSubjects = <String>{};
    final subjectsByGrade = getSubjectsByGrade(languageCode);

    for (final grade in subjectsByGrade.keys) {
      final subjects = subjectsByGrade[grade] ?? [];
      for (final subject in subjects) {
        allSubjects.add(subject.name);
      }
    }
    return allSubjects.toList();
  }

  static List<int> get availableGrades => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

  static List<Subject> getSubjectsForGrade(int grade, String languageCode) {
    final subjectsByGrade = getSubjectsByGrade(languageCode);
    return subjectsByGrade[grade] ?? [];
  }

  static bool hasSubjectsForGrade(int grade, String languageCode) {
    final subjectsByGrade = getSubjectsByGrade(languageCode);
    return subjectsByGrade.containsKey(grade) && subjectsByGrade[grade]!.isNotEmpty;
  }

  // Метод для получения локализованного названия предмета
  String getLocalizedSubjectName(String subjectName, BuildContext context) {
    final appLocalizations = AppLocalizations.of(context);

    switch (subjectName) {
      case 'Математика':
        return appLocalizations.math;
      case 'Русский язык':
        return appLocalizations.russianLanguage;
      case 'Алгебра':
        return appLocalizations.algebra;
      case 'Геометрия':
        return appLocalizations.geometry;
      case 'Физика':
        return appLocalizations.physics;
      case 'Химия':
        return appLocalizations.chemistry;
      case 'Биология':
        return appLocalizations.biology;
      case 'История России':
        return appLocalizations.russianHistory;
      case 'Всеобщая история':
        return appLocalizations.worldHistory;
      case 'География':
        return appLocalizations.geography;
      case 'Обществознание':
        return appLocalizations.socialStudies;
      case 'Английский язык':
        return appLocalizations.englishLanguage;
      case 'Литература':
        return appLocalizations.literature;
      case 'Информатика':
        return appLocalizations.computerScience;
      case 'Статистика и вероятность':
        return appLocalizations.statisticsProbability;
      default:
        return subjectName;
    }
  }

  // Метод для получения оригинального названия предмета из локализованного
  String getOriginalSubjectName(String localizedName, BuildContext context) {
    final appLocalizations = AppLocalizations.of(context);

    // Создаем обратное отображение
    final reverseMap = {
      appLocalizations.math: 'Математика',
      appLocalizations.russianLanguage: 'Русский язык',
      appLocalizations.algebra: 'Алгебра',
      appLocalizations.geometry: 'Геометрия',
      appLocalizations.physics: 'Физика',
      appLocalizations.chemistry: 'Химия',
      appLocalizations.biology: 'Биология',
      appLocalizations.russianHistory: 'История России',
      appLocalizations.worldHistory: 'Всеобщая история',
      appLocalizations.geography: 'География',
      appLocalizations.socialStudies: 'Обществознание',
      appLocalizations.englishLanguage: 'Английский язык',
      appLocalizations.literature: 'Литература',
      appLocalizations.computerScience: 'Информатика',
      appLocalizations.statisticsProbability: 'Статистика и вероятность',
    };

    return reverseMap[localizedName] ?? localizedName;
  }

  // Метод для получения списка локализованных предметов
  List<String> getLocalizedSubjects(BuildContext context) {
    final appLocalizations = AppLocalizations.of(context);
    final languageCode = appLocalizations.locale.languageCode;

    final subjects = getAvailableSubjects(languageCode);
    return subjects.map((subject) => getLocalizedSubjectName(subject, context)).toList();
  }

  // Метод для получения локализованного названия класса
  String getLocalizedGrade(int grade, BuildContext context) {
    final appLocalizations = AppLocalizations.of(context);
    return '$grade ${appLocalizations.gradeClass}';
  }
}

// Emoji для предметов (остаются без изменений, так как это иконки)
final Map<String, String> subjectEmojis = {
  'Математика': '🔢',
  'Русский язык': '📚',
  'Алгебра': '➗',
  'Геометрия': '🔺',
  'Физика': '⚡',
  'Химия': '🧪',
  'Биология': '🌿',
  'История России': '🏛️',
  'Всеобщая история': '🏛️',
  'География': '🌍',
  'Обществознание': '⚖️',
  'Английский язык': '🇬🇧',
  'Литература': '📖',
  'Информатика': '💻',
  'Статистика и вероятность': '📊',
};