import '../../models/subject.dart';
import '../../models/topic.dart';
import '../../models/question.dart';
import 'algebra_localization.dart';

class AlgebraData {
  static List<Subject> getAlgebraSubjectsByGrade(int grade, String languageCode) {
    switch (grade) {
      case 5: return [_createAlgebraSubject5(languageCode)];
      case 6: return [_createAlgebraSubject6(languageCode)];
      default: return [];
    }
  }

  // === 5 КЛАСС ===
  static Subject _createAlgebraSubject5(String languageCode) {
    return Subject(
      name: 'Алгебра',
      topicsByGrade: {
        5: [
          _createNaturalNumbersTopic(languageCode),
          _createSimpleCalculationsTopic(languageCode),
          _createPropertiesTopic(languageCode),
        ],
      },
    );
  }

  static Topic _createNaturalNumbersTopic(String languageCode) {
    return Topic(
      id: 'algebra_5_natural_numbers',
      name: AlgebraLocalization.getNaturalNumbersName(languageCode),
      imageAsset: '🔢',
      description: AlgebraLocalization.getNaturalNumbersDescription(languageCode),
      explanation: AlgebraLocalization.getNaturalNumbersExplanation(languageCode),
      questions: _createNaturalNumbersQuestions(languageCode),
    );
  }

  static List<Question> _createNaturalNumbersQuestions(String languageCode) {
    return [
      Question(
        text: AlgebraLocalization.getNaturalNumbersQuestion(languageCode, 0),
        options: ['42', '32', '52', '38', '45'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getNaturalNumbersAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getNaturalNumbersQuestion(languageCode, 1),
        options: ['1000', '998', '1001', '990', '100'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getNaturalNumbersAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getNaturalNumbersQuestion(languageCode, 2),
        options: ['29', '27', '31', '30', '32'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getNaturalNumbersAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getNaturalNumbersQuestion(languageCode, 3),
        options: ['96', '84', '108', '72', '100'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getNaturalNumbersAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getNaturalNumbersQuestion(languageCode, 4),
        options: ['12', '11', '13', '14', '10'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getNaturalNumbersAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
    ];
  }

  static Topic _createSimpleCalculationsTopic(String languageCode) {
    return Topic(
      id: 'algebra_5_simple_calculations',
      name: AlgebraLocalization.getSimpleCalculationsName(languageCode),
      imageAsset: '➕',
      description: AlgebraLocalization.getSimpleCalculationsDescription(languageCode),
      explanation: AlgebraLocalization.getSimpleCalculationsExplanation(languageCode),
      questions: _createSimpleCalculationsQuestions(languageCode),
    );
  }

  static List<Question> _createSimpleCalculationsQuestions(String languageCode) {
    return [
      Question(
        text: AlgebraLocalization.getSimpleCalculationsQuestion(languageCode, 0),
        options: ['63', '56', '72', '54', '64'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getSimpleCalculationsAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getSimpleCalculationsQuestion(languageCode, 1),
        options: ['8', '7', '9', '6', '5'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getSimpleCalculationsAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getSimpleCalculationsQuestion(languageCode, 2),
        options: ['85', '75', '90', '80', '95'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getSimpleCalculationsAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getSimpleCalculationsQuestion(languageCode, 3),
        options: ['63', '73', '53', '67', '60'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getSimpleCalculationsAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getSimpleCalculationsQuestion(languageCode, 4),
        options: ['90', '80', '100', '75', '85'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getSimpleCalculationsAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
    ];
  }

  static Topic _createPropertiesTopic(String languageCode) {
    return Topic(
      id: 'algebra_5_properties',
      name: AlgebraLocalization.getPropertiesName(languageCode),
      imageAsset: '⚖️',
      description: AlgebraLocalization.getPropertiesDescription(languageCode),
      explanation: AlgebraLocalization.getPropertiesExplanation(languageCode),
      questions: _createPropertiesQuestions(languageCode),
    );
  }

  static List<Question> _createPropertiesQuestions(String languageCode) {
    final propertiesOptions = AlgebraLocalization.getPropertiesOptions(languageCode);

    return [
      Question(
        text: AlgebraLocalization.getPropertiesQuestion(languageCode, 0),
        options: ['63', '53', '73', '60', '65'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getPropertiesAnswerExplanation(languageCode, 0),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getPropertiesQuestion(languageCode, 1),
        options: ['25', '22', '28', '20', '30'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getPropertiesAnswerExplanation(languageCode, 1),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getPropertiesQuestion(languageCode, 2),
        options: List.from(propertiesOptions),
        correctIndex: 0,
        explanation: AlgebraLocalization.getPropertiesAnswerExplanation(languageCode, 2),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getPropertiesQuestion(languageCode, 3),
        options: ['88', '78', '98', '68', '90'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getPropertiesAnswerExplanation(languageCode, 3),
        answerType: 'choice',
      ),
      Question(
        text: AlgebraLocalization.getPropertiesQuestion(languageCode, 4),
        options: ['156', '0', '1', '100', '200'],
        correctIndex: 0,
        explanation: AlgebraLocalization.getPropertiesAnswerExplanation(languageCode, 4),
        answerType: 'choice',
      ),
    ];
  }
}