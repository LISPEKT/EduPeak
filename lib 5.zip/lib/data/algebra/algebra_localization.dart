class AlgebraLocalization {
  static const Map<String, Map<String, String>> _localizedValues = {
    'ru': {
      // Названия тем для 5 класса
      'natural_numbers': 'Натуральные числа',
      'simple_calculations': 'Простые вычисления',
      'addition_subtraction_properties': 'Свойства сложения и вычитания',
      'properties': 'Свойства операций',

      // Описания тем для 5 класса
      'natural_numbers_desc': 'Основные операции с натуральными числами',
      'simple_calculations_desc': 'Умножение и деление натуральных чисел',
      'addition_subtraction_properties_desc': 'Переместительное и сочетательное свойства',
      'properties_desc': 'Переместительное и сочетательное свойства',

      // Объяснения тем для 5 класса
      'natural_numbers_expl': 'Натуральные числа - это числа для счёта предметов (1, 2, 3, ...)',
      'simple_calculations_expl': 'Умножение - это повторное сложение, деление - обратная операция',
      'addition_subtraction_properties_expl': 'Свойства операций помогают упрощать вычисления',
      'properties_expl': 'Свойства операций помогают упрощать вычисления',

      // Вопросы для темы "Натуральные числа"
      'natural_numbers_q1': 'Чему равно 15 + 27?',
      'natural_numbers_q2': 'Какое число следует за 999?',
      'natural_numbers_q3': 'Вычислите: 48 - 19',
      'natural_numbers_q4': 'Найдите произведение 12 и 8',
      'natural_numbers_q5': 'Разделите 144 на 12',

      // Объяснения для темы "Натуральные числа"
      'natural_numbers_expl1': '15 + 27 = 42',
      'natural_numbers_expl2': 'После 999 идет 1000',
      'natural_numbers_expl3': '48 - 19 = 29',
      'natural_numbers_expl4': '12 × 8 = 96',
      'natural_numbers_expl5': '144 ÷ 12 = 12',

      // Вопросы для темы "Простые вычисления"
      'simple_calculations_q1': 'Чему равно 7 × 9?',
      'simple_calculations_q2': 'Вычислите: 56 ÷ 7',
      'simple_calculations_q3': 'Найдите сумму: 23 + 47 + 15',
      'simple_calculations_q4': 'Разность 100 и 37 равна?',
      'simple_calculations_q5': 'Произведение 15 и 6 равно?',

      // Объяснения для темы "Простые вычисления"
      'simple_calculations_expl1': '7 × 9 = 63',
      'simple_calculations_expl2': '56 ÷ 7 = 8',
      'simple_calculations_expl3': '23 + 47 = 70, 70 + 15 = 85',
      'simple_calculations_expl4': '100 - 37 = 63',
      'simple_calculations_expl5': '15 × 6 = 90',

      // Вопросы для темы "Свойства операций"
      'properties_q1': 'Чему равно 25 + 38, если 38 + 25 = 63?',
      'properties_q2': 'Используя сочетательное свойство, вычислите: (15 + 7) + 3',
      'properties_q3': 'Какое свойство выражает равенство a + b = b + a?',
      'properties_q4': 'Вычислите удобным способом: 47 + 28 + 13',
      'properties_q5': 'Чему равно 0 + 156?',

      // Объяснения для темы "Свойства операций"
      'properties_expl1': 'Переместительное свойство: от перестановки слагаемых сумма не меняется',
      'properties_expl2': '(15 + 7) + 3 = 15 + (7 + 3) = 15 + 10 = 25',
      'properties_expl3': 'Это переместительное свойство сложения',
      'properties_expl4': '47 + 13 + 28 = 60 + 28 = 88',
      'properties_expl5': 'При сложении с нулем число не меняется',

      // Варианты ответов
      'commutative': 'Переместительное',
      'associative': 'Сочетательное',
      'distributive': 'Распределительное',
    },
    'en': {
      // Названия тем для 5 класса
      'natural_numbers': 'Natural Numbers',
      'simple_calculations': 'Simple Calculations',
      'addition_subtraction_properties': 'Addition and Subtraction Properties',
      'properties': 'Operation Properties',

      // Описания тем для 5 класса
      'natural_numbers_desc': 'Basic operations with natural numbers',
      'simple_calculations_desc': 'Multiplication and division of natural numbers',
      'addition_subtraction_properties_desc': 'Commutative and associative properties',
      'properties_desc': 'Commutative and associative properties',

      // Объяснения тем для 5 класса
      'natural_numbers_expl': 'Natural numbers are numbers for counting objects (1, 2, 3, ...)',
      'simple_calculations_expl': 'Multiplication is repeated addition, division is the inverse operation',
      'addition_subtraction_properties_expl': 'Operation properties help simplify calculations',
      'properties_expl': 'Operation properties help simplify calculations',

      // Вопросы для темы "Натуральные числа"
      'natural_numbers_q1': 'What is 15 + 27?',
      'natural_numbers_q2': 'What number comes after 999?',
      'natural_numbers_q3': 'Calculate: 48 - 19',
      'natural_numbers_q4': 'Find the product of 12 and 8',
      'natural_numbers_q5': 'Divide 144 by 12',

      // Объяснения для темы "Натуральные числа"
      'natural_numbers_expl1': '15 + 27 = 42',
      'natural_numbers_expl2': 'After 999 comes 1000',
      'natural_numbers_expl3': '48 - 19 = 29',
      'natural_numbers_expl4': '12 × 8 = 96',
      'natural_numbers_expl5': '144 ÷ 12 = 12',

      // Вопросы для темы "Простые вычисления"
      'simple_calculations_q1': 'What is 7 × 9?',
      'simple_calculations_q2': 'Calculate: 56 ÷ 7',
      'simple_calculations_q3': 'Find the sum: 23 + 47 + 15',
      'simple_calculations_q4': 'The difference between 100 and 37 is?',
      'simple_calculations_q5': 'The product of 15 and 6 is?',

      // Объяснения для темы "Простые вычисления"
      'simple_calculations_expl1': '7 × 9 = 63',
      'simple_calculations_expl2': '56 ÷ 7 = 8',
      'simple_calculations_expl3': '23 + 47 = 70, 70 + 15 = 85',
      'simple_calculations_expl4': '100 - 37 = 63',
      'simple_calculations_expl5': '15 × 6 = 90',

      // Вопросы для темы "Свойства операций"
      'properties_q1': 'What is 25 + 38 if 38 + 25 = 63?',
      'properties_q2': 'Using the associative property, calculate: (15 + 7) + 3',
      'properties_q3': 'Which property expresses the equality a + b = b + a?',
      'properties_q4': 'Calculate in a convenient way: 47 + 28 + 13',
      'properties_q5': 'What is 0 + 156?',

      // Объяснения для темы "Свойства операций"
      'properties_expl1': 'Commutative property: the sum does not change when the addends are rearranged',
      'properties_expl2': '(15 + 7) + 3 = 15 + (7 + 3) = 15 + 10 = 25',
      'properties_expl3': 'This is the commutative property of addition',
      'properties_expl4': '47 + 13 + 28 = 60 + 28 = 88',
      'properties_expl5': 'When adding zero, the number does not change',

      // Варианты ответов
      'commutative': 'Commutative',
      'associative': 'Associative',
      'distributive': 'Distributive',
    },
    'de': {
      // Названия тем для 5 класса
      'natural_numbers': 'Natürliche Zahlen',
      'simple_calculations': 'Einfache Berechnungen',
      'addition_subtraction_properties': 'Eigenschaften der Addition und Subtraktion',
      'properties': 'Operationseigenschaften',

      // Описания тем для 5 класса
      'natural_numbers_desc': 'Grundlegende Operationen mit natürlichen Zahlen',
      'simple_calculations_desc': 'Multiplikation und Division natürlicher Zahlen',
      'addition_subtraction_properties_desc': 'Kommutativ- und Assoziativgesetz',
      'properties_desc': 'Kommutativ- und Assoziativgesetz',

      // Объяснения тем для 5 класса
      'natural_numbers_expl': 'Natürliche Zahlen sind Zahlen zum Zählen von Objekten (1, 2, 3, ...)',
      'simple_calculations_expl': 'Multiplikation ist wiederholte Addition, Division ist die umgekehrte Operation',
      'addition_subtraction_properties_expl': 'Operationseigenschaften helfen bei der Vereinfachung von Berechnungen',
      'properties_expl': 'Operationseigenschaften helfen bei der Vereinfachung von Berechnungen',

      // Вопросы для темы "Натуральные числа"
      'natural_numbers_q1': 'Was ist 15 + 27?',
      'natural_numbers_q2': 'Welche Zahl kommt nach 999?',
      'natural_numbers_q3': 'Berechne: 48 - 19',
      'natural_numbers_q4': 'Finde das Produkt von 12 und 8',
      'natural_numbers_q5': 'Teile 144 durch 12',

      // Объяснения для темы "Натуральные числа"
      'natural_numbers_expl1': '15 + 27 = 42',
      'natural_numbers_expl2': 'Nach 999 kommt 1000',
      'natural_numbers_expl3': '48 - 19 = 29',
      'natural_numbers_expl4': '12 × 8 = 96',
      'natural_numbers_expl5': '144 ÷ 12 = 12',

      // Вопросы для темы "Простые вычисления"
      'simple_calculations_q1': 'Was ist 7 × 9?',
      'simple_calculations_q2': 'Berechne: 56 ÷ 7',
      'simple_calculations_q3': 'Finde die Summe: 23 + 47 + 15',
      'simple_calculations_q4': 'Die Differenz zwischen 100 und 37 ist?',
      'simple_calculations_q5': 'Das Produkt von 15 und 6 ist?',

      // Объяснения для темы "Простые вычисления"
      'simple_calculations_expl1': '7 × 9 = 63',
      'simple_calculations_expl2': '56 ÷ 7 = 8',
      'simple_calculations_expl3': '23 + 47 = 70, 70 + 15 = 85',
      'simple_calculations_expl4': '100 - 37 = 63',
      'simple_calculations_expl5': '15 × 6 = 90',

      // Вопросы для темы "Свойства операций"
      'properties_q1': 'Was ist 25 + 38, wenn 38 + 25 = 63?',
      'properties_q2': 'Berechne mit dem Assoziativgesetz: (15 + 7) + 3',
      'properties_q3': 'Welche Eigenschaft drückt die Gleichheit a + b = b + a aus?',
      'properties_q4': 'Berechne auf bequeme Weise: 47 + 28 + 13',
      'properties_q5': 'Was ist 0 + 156?',

      // Объяснения для темы "Свойства операций"
      'properties_expl1': 'Kommutativgesetz: Die Summe ändert sich nicht, wenn die Summanden vertauscht werden',
      'properties_expl2': '(15 + 7) + 3 = 15 + (7 + 3) = 15 + 10 = 25',
      'properties_expl3': 'Dies ist das Kommutativgesetz der Addition',
      'properties_expl4': '47 + 13 + 28 = 60 + 28 = 88',
      'properties_expl5': 'Beim Addieren von Null ändert sich die Zahl nicht',

      // Варианты ответов
      'commutative': 'Kommutativ',
      'associative': 'Assoziativ',
      'distributive': 'Distributiv',
    },
  };

  // Методы для получения локализованных строк
  static String getLocalizedString(String languageCode, String key) {
    return _localizedValues[languageCode]?[key] ?? _localizedValues['ru']![key]!;
  }

  // Методы для тем 5 класса
  static String getNaturalNumbersName(String languageCode) {
    return getLocalizedString(languageCode, 'natural_numbers');
  }

  static String getNaturalNumbersDescription(String languageCode) {
    return getLocalizedString(languageCode, 'natural_numbers_desc');
  }

  static String getNaturalNumbersExplanation(String languageCode) {
    return getLocalizedString(languageCode, 'natural_numbers_expl');
  }

  // Методы для вопросов
  static String getNaturalNumbersQuestion(String languageCode, int questionIndex) {
    final key = 'natural_numbers_q${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  static String getNaturalNumbersAnswerExplanation(String languageCode, int questionIndex) {
    final key = 'natural_numbers_expl${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  // Аналогичные методы для других тем...
  static String getSimpleCalculationsName(String languageCode) {
    return getLocalizedString(languageCode, 'simple_calculations');
  }

  static String getSimpleCalculationsDescription(String languageCode) {
    return getLocalizedString(languageCode, 'simple_calculations_desc');
  }

  static String getSimpleCalculationsExplanation(String languageCode) {
    return getLocalizedString(languageCode, 'simple_calculations_expl');
  }

  static String getSimpleCalculationsQuestion(String languageCode, int questionIndex) {
    final key = 'simple_calculations_q${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  static String getSimpleCalculationsAnswerExplanation(String languageCode, int questionIndex) {
    final key = 'simple_calculations_expl${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  // Методы для темы "Свойства операций"
  static String getPropertiesName(String languageCode) {
    return getLocalizedString(languageCode, 'properties');
  }

  static String getPropertiesDescription(String languageCode) {
    return getLocalizedString(languageCode, 'properties_desc');
  }

  static String getPropertiesExplanation(String languageCode) {
    return getLocalizedString(languageCode, 'properties_expl');
  }

  static String getPropertiesQuestion(String languageCode, int questionIndex) {
    final key = 'properties_q${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  static String getPropertiesAnswerExplanation(String languageCode, int questionIndex) {
    final key = 'properties_expl${questionIndex + 1}';
    return getLocalizedString(languageCode, key);
  }

  // Методы для вариантов ответов
  static List<String> getPropertiesOptions(String languageCode) {
    return [
      getLocalizedString(languageCode, 'commutative'),
      getLocalizedString(languageCode, 'associative'),
      getLocalizedString(languageCode, 'distributive'),
    ];
  }
}